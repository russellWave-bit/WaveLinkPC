using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WaveLinkPC
{
    class PhoneInfo
    {
        public string Id = "", Name = "Phone", Ip = "";
        public int Port = 8180;
    }

    class Item
    {
        public int Id;
        public string Name = "";
        public long Size;
        public string Kind = "file";
    }

    /// <summary>
    /// Finding the phone without any address to type. We knock on every address of the local network(s)
    /// (outgoing connections only, so Windows Firewall never gets in the way) and the phone answers /hello.
    /// </summary>
    static class Disco
    {
        public const int PortFrom = 8180, PortTo = 8183;

        public static List<string> LocalAddresses()
        {
            var l = new List<string>();
            try
            {
                foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;
                    if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback || ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                    foreach (UnicastIPAddressInformation ua in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ua.Address.AddressFamily != AddressFamily.InterNetwork) continue;
                        string s = ua.Address.ToString();
                        if (s.StartsWith("169.254.") || s.StartsWith("127.")) continue;
                        l.Add(s);
                    }
                }
            }
            catch (Exception) { }
            return l;
        }

        /// <summary>A tiny HTTP call over a plain socket. Returns the body, or null.</summary>
        public static async Task<string> Raw(string ip, int port, string request, int connectMs, int readMs)
        {
            TcpClient c = new TcpClient();
            try
            {
                Task conn = c.ConnectAsync(ip, port);
                if (await Task.WhenAny(conn, Task.Delay(connectMs)) != conn || !c.Connected) return null;
                NetworkStream ns = c.GetStream();
                byte[] req = Encoding.ASCII.GetBytes(request);
                await ns.WriteAsync(req, 0, req.Length);
                var ms = new MemoryStream();
                byte[] buf = new byte[4096];
                DateTime end = DateTime.UtcNow.AddMilliseconds(readMs);
                while (ms.Length < 65536)
                {
                    Task<int> rd = ns.ReadAsync(buf, 0, buf.Length);
                    int left = (int)(end - DateTime.UtcNow).TotalMilliseconds;
                    if (left < 1 || await Task.WhenAny(rd, Task.Delay(left)) != rd) break;
                    int n = rd.Result;
                    if (n <= 0) break;
                    ms.Write(buf, 0, n);
                }
                string all = Encoding.UTF8.GetString(ms.ToArray());
                int h = all.IndexOf("\r\n\r\n", StringComparison.Ordinal);
                return h < 0 ? null : all.Substring(h + 4);
            }
            catch (Exception) { return null; }
            finally { try { c.Close(); } catch (Exception) { } }
        }

        public static async Task<PhoneInfo> Hello(string ip, int port, int connectMs)
        {
            string body = await Raw(ip, port, "GET /hello HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n", connectMs, 1500);
            if (body == null) return null;
            var d = Json.Parse(body) as Dictionary<string, object>;
            if (d == null || !d.ContainsKey("app") || (d["app"] as string) != "wavelink") return null;
            var p = new PhoneInfo();
            p.Ip = ip;
            p.Port = port;
            object o;
            if (d.TryGetValue("id", out o)) p.Id = Convert.ToString(o);
            if (d.TryGetValue("name", out o)) p.Name = Convert.ToString(o);
            return p;
        }

        /// <summary>Tries the phones we know first (fast), then sweeps the local networks.</summary>
        public static async Task<List<PhoneInfo>> Find(CancellationToken ct)
        {
            var found = new List<PhoneInfo>();
            foreach (string[] k in Cfg.Phones.ToArray())
            {
                int pt;
                int.TryParse(k[4], out pt);
                PhoneInfo p = await Hello(k[3], pt == 0 ? 8180 : pt, 500);
                if (p != null) { found.Add(p); return found; }
            }
            var hosts = new List<string>();
            var seen = new HashSet<string>();
            foreach (string me in LocalAddresses())
            {
                string[] o = me.Split('.');
                string pre = o[0] + "." + o[1] + "." + o[2] + ".";
                for (int i = 1; i < 255; i++)
                {
                    string h = pre + i;
                    if (h != me && seen.Add(h)) hosts.Add(h);
                }
            }
            var gate = new SemaphoreSlim(160);
            var tasks = new List<Task>();
            object lk = new object();
            foreach (string h in hosts)
            {
                for (int port = PortFrom; port <= PortTo; port++)
                {
                    string hh = h;
                    int pp = port;
                    tasks.Add(Task.Run(async () =>
                    {
                        await gate.WaitAsync();
                        try
                        {
                            if (ct.IsCancellationRequested) return;
                            PhoneInfo p = await Hello(hh, pp, 450);
                            if (p != null) lock (lk) found.Add(p);
                        }
                        finally { gate.Release(); }
                    }));
                }
            }
            await Task.WhenAll(tasks);
            return found;
        }
    }

    /// <summary>One paired phone: asks for its list, keeps in touch, and carries the token.</summary>
    class Link
    {
        public static readonly HttpClient Http = Make();
        public PhoneInfo Phone;
        public string Token = "";

        static HttpClient Make()
        {
            var h = new SocketsHttpHandler();
            h.MaxConnectionsPerServer = 64;
            h.ConnectTimeout = TimeSpan.FromSeconds(4);
            h.UseProxy = false;
            h.AllowAutoRedirect = false;
            var c = new HttpClient(h);
            c.Timeout = Timeout.InfiniteTimeSpan;
            return c;
        }

        public string Base { get { return "http://" + Phone.Ip + ":" + Phone.Port; } }

        public HttpRequestMessage Req(HttpMethod m, string path)
        {
            var r = new HttpRequestMessage(m, Base + path);
            r.Headers.ConnectionClose = true;
            r.Headers.ExpectContinue = false;
            if (Token.Length > 0) r.Headers.Add("X-WL-Token", Token);
            return r;
        }

        /// <summary>Asks the phone to link. The phone shows Allow / Not now; this waits up to a minute.</summary>
        public static async Task<string> Pair(PhoneInfo p)
        {
            try
            {
                var l = new Link();
                l.Phone = p;
                var r = l.Req(HttpMethod.Post, "/pair?id=" + Uri.EscapeDataString(Cfg.PcId) + "&pc=" + Uri.EscapeDataString(Cfg.PcName));
                r.Content = new ByteArrayContent(new byte[0]);
                var cts = new CancellationTokenSource(TimeSpan.FromSeconds(75));
                using (HttpResponseMessage resp = await Http.SendAsync(r, cts.Token))
                {
                    if (!resp.IsSuccessStatusCode) return null;
                    var d = Json.Parse(await resp.Content.ReadAsStringAsync()) as Dictionary<string, object>;
                    object t;
                    if (d != null && d.TryGetValue("token", out t)) return Convert.ToString(t);
                }
            }
            catch (Exception) { }
            return null;
        }

        /// <summary>The phone's shared list. Returns null when the phone cannot be reached, and sets Unauthorized when the token was refused.</summary>
        public bool Unauthorized;

        public async Task<List<Item>> Items()
        {
            try
            {
                var cts = new CancellationTokenSource(TimeSpan.FromSeconds(6));
                using (HttpResponseMessage resp = await Http.SendAsync(Req(HttpMethod.Get, "/items"), cts.Token))
                {
                    if ((int)resp.StatusCode == 401) { Unauthorized = true; return null; }
                    if (!resp.IsSuccessStatusCode) return null;
                    var d = Json.Parse(await resp.Content.ReadAsStringAsync()) as Dictionary<string, object>;
                    if (d == null) return null;
                    var l = new List<Item>();
                    var arr = d["items"] as List<object>;
                    if (arr != null)
                        foreach (object o in arr)
                        {
                            var e = o as Dictionary<string, object>;
                            if (e == null) continue;
                            var it = new Item();
                            it.Id = (int)Convert.ToDouble(e["id"]);
                            it.Name = Convert.ToString(e["name"]);
                            it.Size = (long)Convert.ToDouble(e["size"]);
                            object k;
                            if (e.TryGetValue("kind", out k)) it.Kind = Convert.ToString(k);
                            l.Add(it);
                        }
                    return l;
                }
            }
            catch (Exception) { return null; }
        }
    }
}
