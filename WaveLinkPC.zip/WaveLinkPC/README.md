# WaveLink PC

The Windows half of WaveLink. Open it, open WaveLink on the phone, and they find each other by themselves.
No passwords, no addresses, no browser.

- First time only: tap **Allow** on the phone. After that it links by itself every time.
- Drop files on the window (or **Choose files**) to send them to the phone.
- **Get** or **Get all** pulls what you shared in the phone's Library. Files land in Downloads\WaveLink.
- Both directions can run at the same time. Big files go in several pieces at once for speed.
- Same Wi-Fi, the phone's hotspot, or a USB cable with USB tethering all work. If no network is shared,
  use "Join my phone's hotspot" once.

Build: upload this zip to its own GitHub repo with WaveLinkPC-build.yml in .github/workflows. It publishes WaveLinkPC.exe.

Protocol (phone serves, PC only connects out so Windows Firewall stays quiet): GET /hello, POST /pair, then with the
X-WL-Token header: GET /items, GET /f/<id> (Range), PUT /put?name&size&off&sid.
