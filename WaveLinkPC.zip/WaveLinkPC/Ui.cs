using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace WaveLinkPC
{
    /// <summary>Sea-glass paper, ink outlines, aqua water. Teal goes to the phone, aqua-blue comes to the PC.</summary>
    static class K
    {
        public static readonly Color Bg = Color.FromArgb(0xDD, 0xEB, 0xF1);
        public static readonly Color Paper = Color.FromArgb(0xF2, 0xF9, 0xFC);
        public static readonly Color Panel = Color.White;
        public static readonly Color Panel2 = Color.FromArgb(0xEA, 0xF4, 0xF8);
        public static readonly Color Line = Color.FromArgb(0xC9, 0xDD, 0xE6);
        public static readonly Color Ink = Color.FromArgb(0x10, 0x34, 0x4E);
        public static readonly Color Text = Ink;
        public static readonly Color Mute = Color.FromArgb(0x6B, 0x87, 0x98);
        public static readonly Color Silver = Ink;
        public static readonly Color Aqua = Color.FromArgb(0x27, 0xB4, 0xD8);
        public static readonly Color AquaD = Color.FromArgb(0x1B, 0x8D, 0xB0);
        public static readonly Color Deep = Color.FromArgb(0x2F, 0x6F, 0xB8);
        public static readonly Color Blue = AquaD;                                  // phone to PC
        public static readonly Color Green = Color.FromArgb(0x2E, 0x9C, 0x8A);      // PC to phone
        public static readonly Color Sand = Aqua;
        public static readonly Color Amber = Color.FromArgb(0xF2, 0xA9, 0x3B);
        public static readonly Color Bad = Color.FromArgb(0xD9, 0x50, 0x3F);

        static readonly Dictionary<string, Font> fonts = new Dictionary<string, Font>();

        public static Font F(float pt, bool bold)
        {
            string k = pt + (bold ? "b" : "r");
            Font f;
            if (!fonts.TryGetValue(k, out f))
            {
                f = new Font(bold ? "Segoe UI Semibold" : "Segoe UI", pt, FontStyle.Regular, GraphicsUnit.Point);
                fonts[k] = f;
            }
            return f;
        }

        public static float Sc(Control c)
        {
#if MONO_CHECK
            return 1f;
#else
            float s = c.DeviceDpi / 96f;
            return s < 0.5f ? 1f : s;
#endif
        }

        public static GraphicsPath Round(RectangleF r, float rad)
        {
            var p = new GraphicsPath();
            float d = Math.Max(1f, rad * 2);
            if (d > r.Width) d = r.Width;
            if (d > r.Height) d = r.Height;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        public static void Smooth(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        }

        public static Color A(Color c, int a)
        {
            return Color.FromArgb(Math.Max(0, Math.Min(255, a)), c);
        }

        public static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
        }

        public static string Size(long b)
        {
            if (b < 0) return "?";
            double d = b;
            if (d >= 1e9) return (d / 1e9).ToString("0.00") + " GB";
            if (d >= 1e6) return (d / 1e6).ToString("0.0") + " MB";
            if (d >= 1e3) return Math.Round(d / 1e3) + " KB";
            return b + " B";
        }
    }

    /// <summary>A rounded button. Filled ones are the main action.</summary>
    class Btn : Control
    {
        public bool Solid;
        public Color Ground = Color.Empty;
        public Color Tint = K.Sand;
        bool hover, down;

        public Btn()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(120, 36);
            Cursor = Cursors.Hand;
            Font = K.F(9.5f, true);
            TabStop = false;
        }

        protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover = false; down = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { down = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { down = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(!Ground.IsEmpty ? Ground : (Parent != null ? Parent.BackColor : K.Bg));
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            var r = new RectangleF(1, 1, Width - 3, Height - 3);
            if (down) r.Offset(0, 1);
            using (var p = K.Round(r, r.Height / 2f))
            {
                if (Solid)
                {
                    Color c = hover ? K.Mix(Tint, Color.White, 0.18f) : Tint;
                    using (var b = new SolidBrush(c)) g.FillPath(b, p);
                    using (var pen = new Pen(K.Ink, 2f)) g.DrawPath(pen, p);
                }
                else
                {
                    using (var b = new SolidBrush(hover ? K.Panel2 : K.Panel)) g.FillPath(b, p);
                    using (var pen = new Pen(hover ? K.Mute : K.Line, 1.5f)) g.DrawPath(pen, p);
                }
            }
            var sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            sf.Trimming = StringTrimming.EllipsisCharacter;
            sf.FormatFlags = StringFormatFlags.NoWrap;
            using (var tb = new SolidBrush(K.Ink))
                g.DrawString(Text, Font, tb, r, sf);
        }
    }

    class RowData
    {
        public string Title = "", Sub = "", Chip = "";
        public float Progress = -1f;
        public Color Color = K.Blue;
        public string Button;
        public object Tag;
        public Color SubColor = K.Mute;
    }

    /// <summary>A scrolling list of rows: a file chip, a name, a line of detail, an optional thick progress bar and an optional button.</summary>
    class Rows : Control
    {
        public List<RowData> Items = new List<RowData>();
        public string Empty = "";
        public event Action<RowData> Click;
        int scroll, hover = -1;
        const int RowH = 62;

        public Rows()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(400, 300);
        }

        int H { get { return (int)(RowH * K.Sc(this)); } }

        public void SetItems(List<RowData> l)
        {
            Items = l;
            int max = Math.Max(0, Items.Count * H - Height);
            if (scroll > max) scroll = max;
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent != null ? Parent.BackColor : K.Bg);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            int max = Math.Max(0, Items.Count * H - Height);
            scroll = Math.Max(0, Math.Min(max, scroll - e.Delta / 2));
            Invalidate();
            base.OnMouseWheel(e);
        }

        RectangleF BtnRect(int i, float sc)
        {
            float w = 74 * sc, h = 30 * sc;
            return new RectangleF(Width - w - 12 * sc, i * H - scroll + (H - h) / 2, w, h);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int i = (e.Y + scroll) / H;
            if (i >= Items.Count) i = -1;
            bool onBtn = i >= 0 && Items[i].Button != null && BtnRect(i, K.Sc(this)).Contains(e.Location);
            Cursor = onBtn ? Cursors.Hand : Cursors.Default;
            if (i != hover) { hover = i; Invalidate(); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { hover = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            int i = (e.Y + scroll) / H;
            if (i >= 0 && i < Items.Count && Items[i].Button != null && BtnRect(i, K.Sc(this)).Contains(e.Location))
            {
                var h = Click;
                if (h != null) h(Items[i]);
            }
            base.OnMouseUp(e);
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            int rh = H;
            if (Items.Count == 0)
            {
                var sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                using (var b = new SolidBrush(K.Mute)) g.DrawString(Empty, K.F(10f, false), b, new RectangleF(16 * sc, 0, Width - 32 * sc, Height), sf);
                return;
            }
            for (int i = 0; i < Items.Count; i++)
            {
                float y = i * rh - scroll;
                if (y + rh < 0 || y > Height) continue;
                RowData d = Items[i];
                var row = new RectangleF(0, y + 3 * sc, Width - 2, rh - 6 * sc);
                using (var p = K.Round(row, 14 * sc))
                {
                    using (var b = new SolidBrush(i == hover ? K.Panel2 : K.Panel)) g.FillPath(b, p);
                    using (var pen = new Pen(K.Line, 1f)) g.DrawPath(pen, p);
                }
                // chip
                var chip = new RectangleF(12 * sc, y + (rh - 38 * sc) / 2, 38 * sc, 38 * sc);
                using (var p = K.Round(chip, 10 * sc))
                {
                    using (var b = new SolidBrush(K.A(d.Color, 40))) g.FillPath(b, p);
                }
                var csf = new StringFormat();
                csf.Alignment = StringAlignment.Center;
                csf.LineAlignment = StringAlignment.Center;
                using (var b = new SolidBrush(d.Color)) g.DrawString(d.Chip, K.F(8f, true), b, chip, csf);

                float left = 62 * sc;
                float right = Width - (d.Button != null ? 96 * sc : 18 * sc);
                var tsf = new StringFormat();
                tsf.Trimming = StringTrimming.EllipsisCharacter;
                tsf.FormatFlags = StringFormatFlags.NoWrap;
                using (var b = new SolidBrush(K.Text)) g.DrawString(d.Title, K.F(10f, true), b, new RectangleF(left, y + 9 * sc, right - left, 20 * sc), tsf);
                using (var b = new SolidBrush(d.SubColor)) g.DrawString(d.Sub, K.F(8.5f, false), b, new RectangleF(left, y + 29 * sc, right - left, 18 * sc), tsf);
                if (d.Button != null)
                {
                    var br = BtnRect(i, sc);
                    using (var p = K.Round(br, br.Height / 2))
                    {
                        using (var b = new SolidBrush(K.A(d.Color, 50))) g.FillPath(b, p);
                        using (var pen = new Pen(K.A(d.Color, 160), 1.3f)) g.DrawPath(pen, p);
                    }
                    var bsf = new StringFormat();
                    bsf.Alignment = StringAlignment.Center;
                    bsf.LineAlignment = StringAlignment.Center;
                    using (var b = new SolidBrush(d.Color)) g.DrawString(d.Button, K.F(9f, true), b, br, bsf);
                }
            }
        }
    }

    /// <summary>The place to drop files for the phone.</summary>
    class DropZone : Control
    {
        public bool Hot;
        public string Label = "Drop files here to send them to the phone";

        public DropZone()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(400, 90);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent != null ? Parent.BackColor : K.Bg);
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            var r = new RectangleF(1.5f, 1.5f, Width - 4, Height - 4);
            using (var p = K.Round(r, 18 * sc))
            {
                using (var b = new SolidBrush(Hot ? K.A(K.Green, 38) : K.Panel)) g.FillPath(b, p);
                using (var pen = new Pen(Hot ? K.Green : K.Line, 2f))
                {
                    pen.DashStyle = DashStyle.Dash;
                    g.DrawPath(pen, p);
                }
            }
            // an arrow pointing right, toward the phone
            float cx = 34 * sc, cy = Height / 2f;
            using (var pen = new Pen(K.Green, 3.5f * sc) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
            {
                g.DrawLine(pen, cx - 10 * sc, cy, cx + 12 * sc, cy);
                g.DrawLines(pen, new PointF[] { new PointF(cx + 4 * sc, cy - 8 * sc), new PointF(cx + 12 * sc, cy), new PointF(cx + 4 * sc, cy + 8 * sc) });
            }
            var sf = new StringFormat();
            sf.LineAlignment = StringAlignment.Center;
            sf.Trimming = StringTrimming.EllipsisWord;
            using (var b = new SolidBrush(Hot ? K.Text : K.Silver))
                g.DrawString(Label, K.F(10.5f, true), b, new RectangleF(62 * sc, 0, Width - 70 * sc, Height), sf);
        }
    }
}
