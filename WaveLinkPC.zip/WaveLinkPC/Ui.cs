using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace WaveLinkPC
{
    /// <summary>Midnight and silver, with two colours for direction: blue goes to the PC, green goes to the phone.</summary>
    static class K
    {
        public static readonly Color Bg = Color.FromArgb(0x0B, 0x10, 0x16);
        public static readonly Color Panel = Color.FromArgb(0x13, 0x1A, 0x23);
        public static readonly Color Panel2 = Color.FromArgb(0x19, 0x22, 0x2D);
        public static readonly Color Line = Color.FromArgb(0x25, 0x31, 0x3E);
        public static readonly Color Text = Color.FromArgb(0xE9, 0xEE, 0xF4);
        public static readonly Color Mute = Color.FromArgb(0x84, 0x93, 0xA5);
        public static readonly Color Silver = Color.FromArgb(0xC9, 0xD2, 0xDD);
        public static readonly Color Blue = Color.FromArgb(0x5B, 0x9B, 0xFF);   // phone to PC
        public static readonly Color Green = Color.FromArgb(0x35, 0xD6, 0xAE);  // PC to phone
        public static readonly Color Sand = Color.FromArgb(0xEB, 0xD0, 0xA2);
        public static readonly Color Bad = Color.FromArgb(0xFF, 0x6B, 0x6B);

        static readonly Dictionary<string, Font> fonts = new Dictionary<string, Font>();

        public static Font F(float pt, bool bold)
        {
            string k = pt + (bold ? "b" : "r");
            Font f;
            if (!fonts.TryGetValue(k, out f))
            {
                f = new Font(bold ? "Segoe UI Semibold" : "Segoe UI", pt, FontStyle.Regular, GraphicsUnit.Point);
                fonts[k] = f;
            }
            return f;
        }

        public static float Sc(Control c)
        {
#if MONO_CHECK
            return 1f;
#else
            float s = c.DeviceDpi / 96f;
            return s < 0.5f ? 1f : s;
#endif
        }

        public static GraphicsPath Round(RectangleF r, float rad)
        {
            var p = new GraphicsPath();
            float d = Math.Max(1f, rad * 2);
            if (d > r.Width) d = r.Width;
            if (d > r.Height) d = r.Height;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        public static void Smooth(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        }

        public static Color A(Color c, int a)
        {
            return Color.FromArgb(Math.Max(0, Math.Min(255, a)), c);
        }

        public static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
        }

        public static string Size(long b)
        {
            if (b < 0) return "?";
            double d = b;
            if (d >= 1e9) return (d / 1e9).ToString("0.00") + " GB";
            if (d >= 1e6) return (d / 1e6).ToString("0.0") + " MB";
            if (d >= 1e3) return Math.Round(d / 1e3) + " KB";
            return b + " B";
        }
    }

    /// <summary>A rounded button. Filled ones are the main action.</summary>
    class Btn : Control
    {
        public bool Solid;
        public Color Ground = Color.Empty;
        public Color Tint = K.Sand;
        bool hover, down;

        public Btn()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(120, 36);
            Cursor = Cursors.Hand;
            Font = K.F(9.5f, true);
            TabStop = false;
        }

        protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover = false; down = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { down = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { down = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(!Ground.IsEmpty ? Ground : (Parent != null ? Parent.BackColor : K.Bg));
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            var r = new RectangleF(1, 1, Width - 3, Height - 3);
            if (down) r.Offset(0, 1);
            using (var p = K.Round(r, r.Height / 2f))
            {
                if (Solid)
                {
                    Color c = hover ? K.Mix(Tint, Color.White, 0.18f) : Tint;
                    using (var b = new SolidBrush(c)) g.FillPath(b, p);
                }
                else
                {
                    using (var b = new SolidBrush(hover ? K.Panel2 : K.Panel)) g.FillPath(b, p);
                    using (var pen = new Pen(hover ? K.Mute : K.Line, 1.5f)) g.DrawPath(pen, p);
                }
            }
            var sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            sf.Trimming = StringTrimming.EllipsisCharacter;
            sf.FormatFlags = StringFormatFlags.NoWrap;
            using (var tb = new SolidBrush(Solid ? Color.FromArgb(0x1A, 0x14, 0x08) : K.Text))
                g.DrawString(Text, Font, tb, r, sf);
        }
    }

    /// <summary>
    /// The stage: this PC on the left, the phone on the right, two waves that cross between them.
    /// Green packets ride the upper wave to the phone, blue packets ride the lower wave to the PC.
    /// Both can run at once. While nothing is linked the waves march slowly, looking for a phone.
    /// </summary>
    class Stage : Control
    {
        public enum S { Searching, Approve, Linked, Denied }
        public S State = S.Searching;
        public string PhoneName = "";
        public string Hint = "";
        public bool ToPhone, ToPc;           // moving right now
        public double ToPhoneMB, ToPcMB;
        public float Flash;                  // 0..1, a quick glow when a file lands
        public bool FlashPhone;              // which device glows
        float t, drift, lk, ua, da;

        public Stage()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(900, 230);
        }

        public void Tick(float dt)
        {
            t = (t + dt / 2.4f) % 1f;
            drift = (drift + dt * 0.7f) % 6.2831855f;
            lk += ((State == S.Linked ? 1f : 0f) - lk) * Math.Min(1f, dt * 6f);
            ua += ((ToPhone ? 1f : 0f) - ua) * Math.Min(1f, dt * 7f);
            da += ((ToPc ? 1f : 0f) - da) * Math.Min(1f, dt * 7f);
            Flash = Math.Max(0f, Flash - dt * 1.4f);
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent != null ? Parent.BackColor : K.Bg);
        }

        float Y(float cy, float amp, float u, float sign)
        {
            return cy + sign * amp * (float)(Math.Sin(Math.PI * u) * Math.Sin(2 * Math.PI * u + drift));
        }

        PointF[] Wave(float x0, float span, float cy, float amp, float sign)
        {
            int n = 90;
            var pts = new PointF[n + 1];
            for (int i = 0; i <= n; i++)
            {
                float u = i / (float)n;
                pts[i] = new PointF(x0 + span * u, Y(cy, amp, u, sign));
            }
            return pts;
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            var r = new RectangleF(0.5f, 0.5f, Width - 2, Height - 2);
            using (var p = K.Round(r, 22 * sc))
            {
                using (var b = new LinearGradientBrush(r, Color.FromArgb(0x16, 0x1F, 0x2A), Color.FromArgb(0x0F, 0x15, 0x1D), 90f)) g.FillPath(b, p);
                using (var pen = new Pen(K.Line, 1.2f)) g.DrawPath(pen, p);
            }

            float cy = Height * 0.5f + 24 * sc;

            // title and state
            string title = "WaveLink", line = "", sub = Hint;
            Color lc = K.Mute;
            switch (State)
            {
                case S.Searching: line = "Looking for your phone..."; break;
                case S.Approve: line = "Tap Allow on your phone"; lc = K.Sand; break;
                case S.Denied: line = "The phone said no. Trying again..."; lc = K.Bad; break;
                default: line = "Linked to " + PhoneName; lc = K.Green; break;
            }
            using (var b = new SolidBrush(K.Text)) g.DrawString(title, K.F(20f, true), b, 26 * sc, 18 * sc);
            using (var b = new SolidBrush(lc)) g.DrawString(line, K.F(11f, true), b, 28 * sc, 52 * sc);
            if (sub.Length > 0) using (var b = new SolidBrush(K.Mute)) g.DrawString(sub, K.F(9.5f, false), b, 28 * sc, 74 * sc);

            // the PC, left: a monitor on a stand
            float mw = 128 * sc, mh = 84 * sc;
            float mx = 52 * sc, my = cy - mh / 2 - 10 * sc;
            float glowPc = (!FlashPhone ? Flash : 0f);
            float glowPh = (FlashPhone ? Flash : 0f);
            var mon = new RectangleF(mx, my, mw, mh);
            using (var p = K.Round(mon, 10 * sc))
            {
                using (var b = new SolidBrush(K.Mix(Color.FromArgb(0x1B, 0x25, 0x31), K.Silver, glowPc * 0.5f))) g.FillPath(b, p);
                using (var pen = new Pen(K.Silver, 3f * sc)) g.DrawPath(pen, p);
            }
            var scr = new RectangleF(mx + 8 * sc, my + 8 * sc, mw - 16 * sc, mh - 16 * sc);
            float pulse = 0.6f + 0.4f * (float)Math.Sin(t * 12.566f);
            using (var p = K.Round(scr, 5 * sc))
            using (var b = new SolidBrush(K.A(K.Blue, (int)(30 + 150 * da * pulse + 60 * glowPc)))) g.FillPath(b, p);
            using (var pen = new Pen(K.Silver, 3f * sc) { StartCap = LineCap.Round, EndCap = LineCap.Round })
            {
                g.DrawLine(pen, mx + mw / 2, my + mh, mx + mw / 2, my + mh + 12 * sc);
                g.DrawLine(pen, mx + mw / 2 - 24 * sc, my + mh + 13 * sc, mx + mw / 2 + 24 * sc, my + mh + 13 * sc);
            }

            // the phone, right
            float pw = 62 * sc, ph = 108 * sc;
            float px = Width - 52 * sc - pw, py = cy - ph / 2 - 6 * sc;
            var phn = new RectangleF(px, py, pw, ph);
            using (var p = K.Round(phn, 14 * sc))
            {
                using (var b = new SolidBrush(K.Mix(Color.FromArgb(0x1B, 0x25, 0x31), K.Silver, glowPh * 0.5f))) g.FillPath(b, p);
                using (var pen = new Pen(K.Silver, 3f * sc)) g.DrawPath(pen, p);
            }
            var ps = new RectangleF(px + 7 * sc, py + 14 * sc, pw - 14 * sc, ph - 28 * sc);
            using (var p = K.Round(ps, 6 * sc))
            using (var b = new SolidBrush(K.A(K.Green, (int)(30 + 150 * ua * pulse + 60 * glowPh)))) g.FillPath(b, p);
            using (var b = new SolidBrush(K.Silver)) g.FillRectangle(b, px + pw / 2 - 7 * sc, py + 6 * sc, 14 * sc, 2.5f * sc);

            // labels under the devices
            var sfc = new StringFormat(); sfc.Alignment = StringAlignment.Center;
            using (var b = new SolidBrush(K.Mute))
            {
                g.DrawString(Cfg.PcName, K.F(9.5f, true), b, new RectangleF(mx - 30 * sc, my + mh + 20 * sc, mw + 60 * sc, 20 * sc), sfc);
                g.DrawString(State == S.Linked ? PhoneName : "Phone", K.F(9.5f, true), b, new RectangleF(px - 40 * sc, py + ph + 8 * sc, pw + 80 * sc, 20 * sc), sfc);
            }
            // link dot on the phone
            using (var b = new SolidBrush(State == S.Linked ? K.Green : K.A(K.Mute, 120))) g.FillEllipse(b, px + pw - 8 * sc, py - 6 * sc, 13 * sc, 13 * sc);
            using (var pen = new Pen(Color.FromArgb(0x16, 0x1F, 0x2A), 2f * sc)) g.DrawEllipse(pen, px + pw - 8 * sc, py - 6 * sc, 13 * sc, 13 * sc);

            // the waves
            float x0 = mx + mw + 28 * sc, x1 = px - 28 * sc;
            float span = Math.Max(10, x1 - x0), amp = 34 * sc;
            bool searching = lk < 0.5f;
            DrawWave(g, Wave(x0, span, cy, amp, +1f), K.Green, searching ? 0.32f : 0.26f + 0.74f * ua, searching, sc);
            DrawWave(g, Wave(x0, span, cy, amp, -1f), K.Blue, searching ? 0.32f : 0.26f + 0.74f * da, searching, sc);
            Packets(g, x0, span, cy, amp, +1f, K.Green, true, ua, sc);
            Packets(g, x0, span, cy, amp, -1f, K.Blue, false, da, sc);

            // speed chips at the bottom
            float by = Height - 44 * sc;
            Chip(g, Width / 2f - 190 * sc, by, "PC to phone", ToPhone ? ToPhoneMB.ToString("0.0") + " MB/s" : "idle", K.Green, ToPhone, sc);
            Chip(g, Width / 2f + 10 * sc, by, "Phone to PC", ToPc ? ToPcMB.ToString("0.0") + " MB/s" : "idle", K.Blue, ToPc, sc);
        }

        void DrawWave(Graphics g, PointF[] pts, Color c, float alpha, bool dashed, float sc)
        {
            using (var pen = new Pen(K.A(c, (int)(255 * alpha)), 4.5f * sc))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                pen.LineJoin = LineJoin.Round;
                if (dashed)
                {
                    pen.DashStyle = DashStyle.Custom;
                    pen.DashPattern = new float[] { 2.2f, 2.8f };
                    pen.DashOffset = -t * 5f;
                }
                g.DrawLines(pen, pts);
            }
        }

        void Packets(Graphics g, float x0, float span, float cy, float amp, float sign, Color c, bool rightward, float a, float sc)
        {
            if (a < 0.03f) return;
            int k = 8;
            for (int i = 0; i < k; i++)
            {
                float ph = (t + i / (float)k) % 1f;
                float u = rightward ? ph : 1f - ph;
                float x = x0 + span * u, y = Y(cy, amp, u, sign);
                float al = (float)Math.Sin(Math.PI * ph) * a;
                var rc = new RectangleF(x - 9 * sc, y - 5 * sc, 18 * sc, 10 * sc);
                using (var p = K.Round(rc, 5 * sc))
                {
                    using (var b = new SolidBrush(K.A(c, (int)(255 * al)))) g.FillPath(b, p);
                    using (var pen = new Pen(K.A(Color.White, (int)(230 * al)), 1.4f * sc)) g.DrawPath(pen, p);
                }
            }
        }

        void Chip(Graphics g, float x, float y, string label, string value, Color c, bool on, float sc)
        {
            using (var b = new SolidBrush(on ? c : K.A(c, 70))) g.FillEllipse(b, x, y + 8 * sc, 12 * sc, 12 * sc);
            using (var b = new SolidBrush(K.Mute)) g.DrawString(label, K.F(8.5f, false), b, x + 20 * sc, y - 2 * sc);
            using (var b = new SolidBrush(on ? c : K.Mute)) g.DrawString(value, K.F(12f, true), b, x + 20 * sc, y + 11 * sc);
        }
    }

    class RowData
    {
        public string Title = "", Sub = "", Chip = "";
        public float Progress = -1f;
        public Color Color = K.Blue;
        public string Button;
        public object Tag;
        public Color SubColor = K.Mute;
    }

    /// <summary>A scrolling list of rows: a file chip, a name, a line of detail, an optional thick progress bar and an optional button.</summary>
    class Rows : Control
    {
        public List<RowData> Items = new List<RowData>();
        public string Empty = "";
        public event Action<RowData> Click;
        int scroll, hover = -1;
        const int RowH = 62;

        public Rows()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(400, 300);
        }

        int H { get { return (int)(RowH * K.Sc(this)); } }

        public void SetItems(List<RowData> l)
        {
            Items = l;
            int max = Math.Max(0, Items.Count * H - Height);
            if (scroll > max) scroll = max;
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent != null ? Parent.BackColor : K.Bg);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            int max = Math.Max(0, Items.Count * H - Height);
            scroll = Math.Max(0, Math.Min(max, scroll - e.Delta / 2));
            Invalidate();
            base.OnMouseWheel(e);
        }

        RectangleF BtnRect(int i, float sc)
        {
            float w = 74 * sc, h = 30 * sc;
            return new RectangleF(Width - w - 12 * sc, i * H - scroll + (H - h) / 2, w, h);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int i = (e.Y + scroll) / H;
            if (i >= Items.Count) i = -1;
            bool onBtn = i >= 0 && Items[i].Button != null && BtnRect(i, K.Sc(this)).Contains(e.Location);
            Cursor = onBtn ? Cursors.Hand : Cursors.Default;
            if (i != hover) { hover = i; Invalidate(); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { hover = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            int i = (e.Y + scroll) / H;
            if (i >= 0 && i < Items.Count && Items[i].Button != null && BtnRect(i, K.Sc(this)).Contains(e.Location))
            {
                var h = Click;
                if (h != null) h(Items[i]);
            }
            base.OnMouseUp(e);
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            int rh = H;
            if (Items.Count == 0)
            {
                var sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                using (var b = new SolidBrush(K.Mute)) g.DrawString(Empty, K.F(10f, false), b, new RectangleF(16 * sc, 0, Width - 32 * sc, Height), sf);
                return;
            }
            for (int i = 0; i < Items.Count; i++)
            {
                float y = i * rh - scroll;
                if (y + rh < 0 || y > Height) continue;
                RowData d = Items[i];
                var row = new RectangleF(0, y + 3 * sc, Width - 2, rh - 6 * sc);
                using (var p = K.Round(row, 14 * sc))
                {
                    using (var b = new SolidBrush(i == hover ? K.Panel2 : K.Panel)) g.FillPath(b, p);
                    using (var pen = new Pen(K.Line, 1f)) g.DrawPath(pen, p);
                }
                // chip
                var chip = new RectangleF(12 * sc, y + (rh - 38 * sc) / 2, 38 * sc, 38 * sc);
                using (var p = K.Round(chip, 10 * sc))
                {
                    using (var b = new SolidBrush(K.A(d.Color, 40))) g.FillPath(b, p);
                }
                var csf = new StringFormat();
                csf.Alignment = StringAlignment.Center;
                csf.LineAlignment = StringAlignment.Center;
                using (var b = new SolidBrush(d.Color)) g.DrawString(d.Chip, K.F(8f, true), b, chip, csf);

                float left = 62 * sc;
                float right = Width - (d.Button != null ? 96 * sc : 18 * sc);
                var tsf = new StringFormat();
                tsf.Trimming = StringTrimming.EllipsisCharacter;
                tsf.FormatFlags = StringFormatFlags.NoWrap;
                using (var b = new SolidBrush(K.Text)) g.DrawString(d.Title, K.F(10f, true), b, new RectangleF(left, y + 9 * sc, right - left, 20 * sc), tsf);
                using (var b = new SolidBrush(d.SubColor)) g.DrawString(d.Sub, K.F(8.5f, false), b, new RectangleF(left, y + 29 * sc, right - left, 18 * sc), tsf);
                if (d.Progress >= 0f)
                {
                    var bar = new RectangleF(left, y + rh - 18 * sc, right - left, 8 * sc);
                    using (var p = K.Round(bar, 4 * sc)) using (var b = new SolidBrush(K.A(d.Color, 38))) g.FillPath(b, p);
                    float w = Math.Max(8 * sc, bar.Width * Math.Min(1f, d.Progress));
                    if (d.Progress > 0f)
                        using (var p = K.Round(new RectangleF(bar.X, bar.Y, w, bar.Height), 4 * sc)) using (var b = new SolidBrush(d.Color)) g.FillPath(b, p);
                }
                if (d.Button != null)
                {
                    var br = BtnRect(i, sc);
                    using (var p = K.Round(br, br.Height / 2))
                    {
                        using (var b = new SolidBrush(K.A(d.Color, 50))) g.FillPath(b, p);
                        using (var pen = new Pen(K.A(d.Color, 160), 1.3f)) g.DrawPath(pen, p);
                    }
                    var bsf = new StringFormat();
                    bsf.Alignment = StringAlignment.Center;
                    bsf.LineAlignment = StringAlignment.Center;
                    using (var b = new SolidBrush(d.Color)) g.DrawString(d.Button, K.F(9f, true), b, br, bsf);
                }
            }
        }
    }

    /// <summary>The place to drop files for the phone.</summary>
    class DropZone : Control
    {
        public bool Hot;
        public string Label = "Drop files here to send them to the phone";

        public DropZone()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(400, 90);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent != null ? Parent.BackColor : K.Bg);
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            var r = new RectangleF(1.5f, 1.5f, Width - 4, Height - 4);
            using (var p = K.Round(r, 18 * sc))
            {
                using (var b = new SolidBrush(Hot ? K.A(K.Green, 38) : K.Panel)) g.FillPath(b, p);
                using (var pen = new Pen(Hot ? K.Green : K.Line, 2f))
                {
                    pen.DashStyle = DashStyle.Dash;
                    g.DrawPath(pen, p);
                }
            }
            // an arrow pointing right, toward the phone
            float cx = 34 * sc, cy = Height / 2f;
            using (var pen = new Pen(K.Green, 3.5f * sc) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
            {
                g.DrawLine(pen, cx - 10 * sc, cy, cx + 12 * sc, cy);
                g.DrawLines(pen, new PointF[] { new PointF(cx + 4 * sc, cy - 8 * sc), new PointF(cx + 12 * sc, cy), new PointF(cx + 4 * sc, cy + 8 * sc) });
            }
            var sf = new StringFormat();
            sf.LineAlignment = StringAlignment.Center;
            sf.Trimming = StringTrimming.EllipsisWord;
            using (var b = new SolidBrush(Hot ? K.Text : K.Silver))
                g.DrawString(Label, K.F(10.5f, true), b, new RectangleF(62 * sc, 0, Width - 70 * sc, Height), sf);
        }
    }
}
