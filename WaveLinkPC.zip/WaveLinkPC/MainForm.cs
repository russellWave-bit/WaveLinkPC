using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WaveLinkPC
{
    class MainForm : Form
    {
        readonly Stage stage = new Stage();
        readonly Rows phoneList = new Rows();
        readonly Rows jobList = new Rows();
        readonly DropZone drop = new DropZone();
        readonly Btn getAll = new Btn();
        readonly Btn openDir = new Btn();
        readonly Btn choose = new Btn();
        readonly Btn unlink = new Btn();
        readonly Btn hotspot = new Btn();
        readonly Engine eng = new Engine();
        readonly System.Windows.Forms.Timer anim = new System.Windows.Forms.Timer();
        readonly CancellationTokenSource cts = new CancellationTokenSource();

        Link link;
        List<Item> items = new List<Item>();
        bool closing;
        int ticks;
        long lastUp, lastDown;
        DateTime lastSpeed = DateTime.UtcNow, searchSince = DateTime.UtcNow;
        Rectangle leftHead, rightHead;

        public MainForm()
        {
            Cfg.Load();
            Text = "WaveLink PC";
            BackColor = K.Bg;
            ForeColor = K.Text;
            ClientSize = new Size(1060, 720);
            MinimumSize = new Size(900, 640);
            StartPosition = FormStartPosition.CenterScreen;
            DoubleBuffered = true;
            AllowDrop = true;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch (Exception) { }

            getAll.Text = "Get all";
            getAll.Solid = true;
            getAll.Tint = K.Blue;
            getAll.Size = new Size(96, 34);
            getAll.Click += (s, e) => GetAll();
            openDir.Text = "Open folder";
            openDir.Size = new Size(110, 34);
            openDir.Click += (s, e) => OpenDir();
            choose.Text = "Choose files";
            choose.Solid = true;
            choose.Tint = K.Green;
            choose.Size = new Size(120, 34);
            choose.Click += (s, e) => Choose();
            unlink.Text = "Unlink";
            unlink.Size = new Size(84, 32);
            unlink.Click += (s, e) => Unlink();
            unlink.Visible = false;
            unlink.Ground = Color.FromArgb(0x16, 0x1F, 0x2A);
            hotspot.Ground = Color.FromArgb(0x14, 0x1C, 0x26);
            hotspot.Text = "Join my phone's hotspot";
            hotspot.Size = new Size(190, 32);
            hotspot.Click += (s, e) => JoinHotspot();
            hotspot.Visible = false;

            phoneList.Empty = "Nothing shared yet.\nOn the phone, open Library and choose files.";
            phoneList.Click += OnPhoneClick;
            jobList.Empty = "Files you send or get appear here.";
            jobList.Click += OnJobClick;

            Controls.Add(stage);
            Controls.Add(phoneList);
            Controls.Add(jobList);
            Controls.Add(drop);
            Controls.Add(getAll);
            Controls.Add(openDir);
            Controls.Add(choose);
            Controls.Add(unlink);
            Controls.Add(hotspot);
            stage.Controls.Add(unlink);
            stage.Controls.Add(hotspot);

            foreach (Control c in new Control[] { this, stage, drop, phoneList, jobList })
            {
                c.AllowDrop = true;
                c.DragEnter += OnDragEnter;
                c.DragLeave += (s, e) => { drop.Hot = false; drop.Invalidate(); };
                c.DragDrop += OnDragDrop;
            }

            eng.Finished += j => { try { BeginInvoke((Action)(() => { stage.Flash = 1f; stage.FlashPhone = j.Up; })); } catch (Exception) { } };
            anim.Interval = 33;
            anim.Tick += (s, e) => Frame();
            anim.Start();
            Layout += (s, e) => LayoutAll();
            LayoutAll();
            Shown += (s, e) => Loop();
            FormClosing += (s, e) => { closing = true; cts.Cancel(); };
        }

        void LayoutAll()
        {
            float sc = K.Sc(this);
            int pad = (int)(20 * sc), gap = (int)(18 * sc);
            int w = ClientSize.Width - pad * 2;
            stage.SetBounds(pad, pad, w, (int)(252 * sc));
            int y0 = stage.Bottom + (int)(18 * sc);
            int colW = (w - gap) / 2;
            int headH = (int)(40 * sc);
            leftHead = new Rectangle(pad, y0, colW, headH);
            rightHead = new Rectangle(pad + colW + gap, y0, colW, headH);
            int listTop = y0 + headH + (int)(6 * sc);
            int listH = Math.Max(60, ClientSize.Height - listTop - pad);
            phoneList.SetBounds(pad, listTop, colW, listH);
            getAll.Location = new Point(leftHead.Right - getAll.Width, y0 + (headH - getAll.Height) / 2 - 2);
            openDir.Location = new Point(getAll.Left - openDir.Width - 8, getAll.Top);
            choose.Location = new Point(rightHead.Right - choose.Width, getAll.Top);
            int dh = (int)(76 * sc);
            drop.SetBounds(rightHead.Left, listTop, colW, dh);
            jobList.SetBounds(rightHead.Left, listTop + dh + (int)(10 * sc), colW, Math.Max(40, listH - dh - (int)(10 * sc)));
            unlink.Location = new Point(stage.Width - unlink.Width - (int)(22 * sc), (int)(20 * sc));
            hotspot.Location = new Point((int)(26 * sc), (int)(106 * sc));
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            K.Smooth(g);
            using (var b = new SolidBrush(K.Text))
            {
                g.DrawString("On your phone", K.F(14f, true), b, leftHead.X + 2, leftHead.Y + 2);
                g.DrawString("Send to your phone", K.F(14f, true), b, rightHead.X + 2, rightHead.Y + 2);
            }
            using (var b = new SolidBrush(K.Mute))
            {
                string c = link == null ? "not linked yet" : (items.Count == 0 ? "nothing shared" : items.Count + (items.Count == 1 ? " item to get" : " items to get"));
                g.DrawString(c, K.F(9f, false), b, leftHead.X + 3, leftHead.Y + 25);
                g.DrawString("Drop files, or choose them. Folders work too.", K.F(9f, false), b, rightHead.X + 3, rightHead.Y + 25);
            }
        }

        // ───────────── animation and numbers ─────────────

        void Frame()
        {
            stage.Tick(0.033f);
            ticks++;
            if (ticks % 6 == 0) RefreshJobs();
            if (ticks % 15 == 0) Speeds();
        }

        void Speeds()
        {
            DateTime now = DateTime.UtcNow;
            double dt = Math.Max(0.1, (now - lastSpeed).TotalSeconds);
            long up = Interlocked.Read(ref eng.BytesUp), down = Interlocked.Read(ref eng.BytesDown);
            double u = (up - lastUp) / dt / 1e6, d = (down - lastDown) / dt / 1e6;
            lastUp = up; lastDown = down; lastSpeed = now;
            stage.ToPhoneMB = u > 0.05 ? stage.ToPhoneMB * 0.4 + u * 0.6 : 0;
            stage.ToPcMB = d > 0.05 ? stage.ToPcMB * 0.4 + d * 0.6 : 0;
        }

        void RefreshJobs()
        {
            Job[] js;
            lock (eng.Jobs) js = eng.Jobs.ToArray();
            bool toPhone = false, toPc = false;
            var rows = new List<RowData>();
            foreach (Job j in js)
            {
                var r = new RowData();
                r.Title = j.Name;
                r.Chip = Chip(j.Name);
                r.Color = j.Up ? K.Green : K.Blue;
                r.Tag = j;
                long done = Interlocked.Read(ref j.Done);
                if (j.State == "Moving" || j.State == "Waiting")
                {
                    if (j.State == "Moving") { if (j.Up) toPhone = true; else toPc = true; }
                    r.Progress = j.Total > 0 ? Math.Min(1f, (float)done / j.Total) : 0f;
                    r.Sub = (j.Up ? "Sending  " : "Getting  ") + (j.State == "Waiting" ? "waiting..." : K.Size(done) + " of " + K.Size(j.Total));
                }
                else if (j.State == "Done")
                {
                    double secs = Math.Max(0.05, (j.Ended - j.Started).TotalSeconds);
                    r.Sub = (j.Up ? "Sent  " : "Saved  ") + K.Size(j.Total) + "  at " + (j.Total / secs / 1e6).ToString("0.0") + " MB/s";
                    r.SubColor = r.Color;
                    if (!j.Up) r.Button = "Show";
                }
                else
                {
                    r.Sub = "Failed: " + j.Note;
                    r.SubColor = K.Bad;
                }
                rows.Add(r);
            }
            stage.ToPhone = toPhone;
            stage.ToPc = toPc;
            jobList.SetItems(rows);
        }

        static string Chip(string name)
        {
            string e = Path.GetExtension(name);
            if (e.Length > 1) e = e.Substring(1).ToUpperInvariant();
            else e = "FILE";
            return e.Length > 4 ? e.Substring(0, 4) : e;
        }

        void RefreshPhone()
        {
            var rows = new List<RowData>();
            foreach (Item it in items)
            {
                var r = new RowData();
                r.Title = it.Name;
                r.Sub = K.Size(it.Size) + (it.Kind == "app" ? "  app" : "");
                r.Chip = it.Kind == "app" ? "APK" : Chip(it.Name);
                r.Color = K.Blue;
                r.Button = "Get";
                r.Tag = it;
                rows.Add(r);
            }
            phoneList.SetItems(rows);
            Invalidate(leftHead);
        }

        // ───────────── finding and linking ─────────────

        async void Loop()
        {
            int misses = 0;
            while (!closing)
            {
                try
                {
                    if (link == null)
                    {
                        if (stage.State != Stage.S.Denied) { stage.State = Stage.S.Searching; }
                        stage.Hint = "Open WaveLink on the phone. Same Wi-Fi, hotspot or USB link.";
                        bool long_ = (DateTime.UtcNow - searchSince).TotalSeconds > 8;
                        hotspot.Visible = long_;
                        List<PhoneInfo> found = await Disco.Find(cts.Token);
                        if (found.Count == 0) { await Task.Delay(1200); continue; }
                        PhoneInfo p = found[0];
                        foreach (PhoneInfo f in found) if (Cfg.Find(f.Id) != null) { p = f; break; }
                        string[] known = Cfg.Find(p.Id);
                        var l = new Link();
                        l.Phone = p;
                        bool ok = false;
                        if (known != null)
                        {
                            l.Token = known[2];
                            List<Item> first = await l.Items();
                            if (first != null) { ok = true; items = first; }
                            else if (!l.Unauthorized) { await Task.Delay(1200); continue; }
                        }
                        if (!ok)
                        {
                            stage.State = Stage.S.Approve;
                            stage.Hint = "Your phone is asking: allow " + Cfg.PcName + "? You only do this once.";
                            hotspot.Visible = false;
                            string token = await Link.Pair(p);
                            if (token == null)
                            {
                                stage.State = Stage.S.Denied;
                                stage.Hint = "Say Allow on the phone when it asks. Asking again in a moment.";
                                await Task.Delay(12000);
                                continue;
                            }
                            l.Token = token;
                            List<Item> first = await l.Items();
                            if (first != null) items = first;
                        }
                        Cfg.Remember(p.Id, p.Name, l.Token, p.Ip, p.Port);
                        link = l;
                        misses = 0;
                        stage.PhoneName = p.Name;
                        stage.State = Stage.S.Linked;
                        stage.Hint = "";
                        hotspot.Visible = false;
                        unlink.Visible = true;
                        RefreshPhone();
                    }
                    else
                    {
                        List<Item> it = await link.Items();
                        if (it == null)
                        {
                            if (link.Unauthorized) { Cfg.Forget(link.Phone.Id); LoseLink(); }
                            else if (++misses >= 3) LoseLink();
                        }
                        else
                        {
                            misses = 0;
                            if (Changed(it)) { items = it; RefreshPhone(); }
                        }
                        await Task.Delay(1500);
                    }
                }
                catch (Exception) { await Task.Delay(1500); }
            }
        }

        bool Changed(List<Item> n)
        {
            if (n.Count != items.Count) return true;
            for (int i = 0; i < n.Count; i++) if (n[i].Id != items[i].Id || n[i].Size != items[i].Size || n[i].Name != items[i].Name) return true;
            return false;
        }

        void LoseLink()
        {
            link = null;
            items = new List<Item>();
            stage.State = Stage.S.Searching;
            unlink.Visible = false;
            searchSince = DateTime.UtcNow;
            RefreshPhone();
        }

        void Unlink()
        {
            if (link != null) Cfg.Forget(link.Phone.Id);
            LoseLink();
        }

        // ───────────── actions ─────────────

        void OnPhoneClick(RowData r)
        {
            var it = r.Tag as Item;
            if (it != null && link != null) eng.Download(link, it);
        }

        void OnJobClick(RowData r)
        {
            var j = r.Tag as Job;
            if (j == null || j.Up || j.Path.Length == 0) return;
            try { Process.Start("explorer.exe", "/select,\"" + j.Path + "\""); } catch (Exception) { }
        }

        void GetAll()
        {
            if (link == null) return;
            foreach (Item it in items.ToArray()) eng.Download(link, it);
        }

        void OpenDir()
        {
            try
            {
                Directory.CreateDirectory(Cfg.Dir);
                Process.Start("explorer.exe", "\"" + Cfg.Dir + "\"");
            }
            catch (Exception) { }
        }

        void Choose()
        {
            if (link == null) { stage.Hint = "Not linked yet. Open WaveLink on the phone first."; return; }
            using (var d = new OpenFileDialog())
            {
                d.Multiselect = true;
                d.Title = "Send to the phone";
                if (d.ShowDialog(this) == DialogResult.OK) Send(d.FileNames);
            }
        }

        void Send(string[] paths)
        {
            if (link == null) return;
            int n = 0;
            foreach (string p in paths)
            {
                try
                {
                    if (File.Exists(p)) { eng.Upload(link, p); n++; }
                    else if (Directory.Exists(p))
                        foreach (string f in Directory.GetFiles(p, "*", SearchOption.AllDirectories))
                        {
                            if (n >= 500) break;
                            eng.Upload(link, f);
                            n++;
                        }
                }
                catch (Exception) { }
            }
        }

        void OnDragEnter(object s, DragEventArgs e)
        {
            if (link != null && e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
                drop.Hot = true;
                drop.Invalidate();
            }
            else e.Effect = DragDropEffects.None;
        }

        void OnDragDrop(object s, DragEventArgs e)
        {
            drop.Hot = false;
            drop.Invalidate();
            var files = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (files != null) Send(files);
        }

        // ───────────── joining the phone's hotspot (once) ─────────────

        void JoinHotspot()
        {
            using (var f = new Form())
            {
                f.Text = "Join your phone's hotspot";
                f.BackColor = K.Panel;
                f.ForeColor = K.Text;
                f.ClientSize = new Size(420, 250);
                f.StartPosition = FormStartPosition.CenterParent;
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.MaximizeBox = false;
                f.MinimizeBox = false;
                var info = new Label();
                info.Text = "Type the hotspot name and password once. Windows remembers it, and WaveLink finds the phone by itself after that.";
                info.SetBounds(20, 16, 380, 52);
                info.Font = K.F(9.5f, false);
                info.ForeColor = K.Silver;
                var l1 = new Label(); l1.Text = "Hotspot name"; l1.SetBounds(20, 76, 380, 18); l1.ForeColor = K.Mute;
                var t1 = new TextBox(); t1.SetBounds(20, 96, 380, 26); t1.Text = Cfg.Ssid;
                var l2 = new Label(); l2.Text = "Password"; l2.SetBounds(20, 130, 380, 18); l2.ForeColor = K.Mute;
                var t2 = new TextBox(); t2.SetBounds(20, 150, 380, 26); t2.Text = Cfg.Pass; t2.UseSystemPasswordChar = true;
                var go = new Button(); go.Text = "Join"; go.SetBounds(300, 196, 100, 34);
                go.DialogResult = DialogResult.OK;
                f.Controls.AddRange(new Control[] { info, l1, t1, l2, t2, go });
                f.AcceptButton = go;
                if (f.ShowDialog(this) != DialogResult.OK || t1.Text.Trim().Length == 0) return;
                Cfg.Ssid = t1.Text.Trim();
                Cfg.Pass = t2.Text;
                Cfg.Save();
                string ssid = Cfg.Ssid, pass = Cfg.Pass;
                stage.Hint = "Joining " + ssid + "...";
                Task.Run(() => WifiJoin(ssid, pass));
            }
        }

        static string Esc(string s)
        {
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
        }

        static void WifiJoin(string ssid, string pass)
        {
            try
            {
                string xml = "<?xml version=\"1.0\"?><WLANProfile xmlns=\"http://www.microsoft.com/networking/WLAN/profile/v1\"><name>" + Esc(ssid) + "</name>" +
                    "<SSIDConfig><SSID><name>" + Esc(ssid) + "</name></SSID></SSIDConfig><connectionType>ESS</connectionType><connectionMode>auto</connectionMode>" +
                    "<MSM><security><authEncryption><authentication>WPA2PSK</authentication><encryption>AES</encryption><useOneX>false</useOneX></authEncryption>" +
                    "<sharedKey><keyType>passPhrase</keyType><protected>false</protected><keyMaterial>" + Esc(pass) + "</keyMaterial></sharedKey></security></MSM></WLANProfile>";
                string tmp = Path.Combine(Path.GetTempPath(), "wl_" + Guid.NewGuid().ToString("N") + ".xml");
                File.WriteAllText(tmp, xml);
                Netsh("wlan add profile filename=\"" + tmp + "\" user=current");
                try { File.Delete(tmp); } catch (Exception) { }
                Netsh("wlan connect name=\"" + ssid + "\"");
            }
            catch (Exception) { }
        }

        static void Netsh(string args)
        {
            var psi = new ProcessStartInfo("netsh", args);
            psi.CreateNoWindow = true;
            psi.UseShellExecute = false;
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            using (Process p = Process.Start(psi)) { if (p != null) p.WaitForExit(15000); }
        }
    }
}
