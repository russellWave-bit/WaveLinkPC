using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WaveLinkPC
{
    class MainForm : Form
    {
        readonly Stage stage = new Stage();
        readonly Rows phoneList = new Rows();
        readonly Rows jobList = new Rows();
        readonly DropZone drop = new DropZone();
        readonly Btn getAll = new Btn();
        readonly Btn openDir = new Btn();
        readonly Btn choose = new Btn();
        readonly Btn unlink = new Btn();
        readonly Btn qrBtn = new Btn();
        readonly Overall bar = new Overall();
        readonly HashSet<Job> batch = new HashSet<Job>();
        bool batchDone;
        readonly Engine eng = new Engine();
        readonly System.Windows.Forms.Timer anim = new System.Windows.Forms.Timer();
        readonly CancellationTokenSource cts = new CancellationTokenSource();

        Link link;
        List<Item> items = new List<Item>();
        bool closing;
        int ticks;
        long lastUp, lastDown;
        DateTime lastSpeed = DateTime.UtcNow, searchSince = DateTime.UtcNow;
        Rectangle leftHead, rightHead;
        float aggSpeed;

        public MainForm()
        {
            Cfg.Load();
            Text = "WaveLink PC";
            BackColor = K.Bg;
            ForeColor = K.Text;
            ClientSize = new Size(1060, 810);
            MinimumSize = new Size(900, 700);
            StartPosition = FormStartPosition.CenterScreen;
            DoubleBuffered = true;
            AllowDrop = true;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch (Exception) { }

            getAll.Text = "Get all";
            getAll.Solid = true;
            getAll.Tint = K.Blue;
            getAll.Size = new Size(96, 34);
            getAll.Click += (s, e) => GetAll();
            openDir.Text = "Open folder";
            openDir.Size = new Size(110, 34);
            openDir.Click += (s, e) => OpenDir();
            choose.Text = "Choose files";
            choose.Solid = true;
            choose.Tint = K.Green;
            choose.Size = new Size(120, 34);
            choose.Click += (s, e) => Choose();
            unlink.Text = "Unlink";
            unlink.Size = new Size(84, 32);
            unlink.Click += (s, e) => Unlink();
            unlink.Visible = false;
            unlink.Ground = Color.White;
            qrBtn.Ground = Color.White;
            qrBtn.Text = "Connect by QR";
            qrBtn.Solid = true;
            qrBtn.Tint = K.Aqua;
            qrBtn.Size = new Size(170, 38);
            qrBtn.Click += (s, e) => ToggleQr();

            phoneList.Empty = "Nothing shared yet.\nOn the phone, open Library and choose files.";
            phoneList.Click += OnPhoneClick;
            jobList.Empty = "Files you send or get appear here.";
            jobList.Click += OnJobClick;

            Controls.Add(stage);
            Controls.Add(phoneList);
            Controls.Add(jobList);
            Controls.Add(drop);
            Controls.Add(getAll);
            Controls.Add(openDir);
            Controls.Add(choose);
            Controls.Add(bar);
            stage.Controls.Add(unlink);
            stage.Controls.Add(qrBtn);

            foreach (Control c in new Control[] { this, stage, drop, phoneList, jobList })
            {
                c.AllowDrop = true;
                c.DragEnter += OnDragEnter;
                c.DragLeave += (s, e) => { drop.Hot = false; drop.Invalidate(); };
                c.DragDrop += OnDragDrop;
            }

            eng.Finished += j => { try { BeginInvoke((Action)(() => { stage.Flash = 1f; stage.FlashPhone = j.Up; })); } catch (Exception) { } };
            anim.Interval = 33;
            anim.Tick += (s, e) => Frame();
            anim.Start();
            Layout += (s, e) => LayoutAll();
            LayoutAll();
            Shown += (s, e) => Loop();
            FormClosing += (s, e) => { closing = true; cts.Cancel(); try { Hot.Stop().Wait(3000); } catch (Exception) { } };
        }

        void LayoutAll()
        {
            float sc = K.Sc(this);
            int pad = (int)(20 * sc), gap = (int)(18 * sc);
            int w = ClientSize.Width - pad * 2;
            stage.SetBounds(pad, pad, w, (int)(236 * sc));
            bar.SetBounds(pad, stage.Bottom + (int)(8 * sc), w, (int)(142 * sc));
            int y0 = bar.Bottom + (int)(8 * sc);
            int colW = (w - gap) / 2;
            int headH = (int)(40 * sc);
            leftHead = new Rectangle(pad, y0, colW, headH);
            rightHead = new Rectangle(pad + colW + gap, y0, colW, headH);
            int listTop = y0 + headH + (int)(6 * sc);
            int listH = Math.Max(60, ClientSize.Height - listTop - pad);
            phoneList.SetBounds(pad, listTop, colW, listH);
            getAll.Location = new Point(leftHead.Right - getAll.Width, y0 + (headH - getAll.Height) / 2 - 2);
            openDir.Location = new Point(getAll.Left - openDir.Width - 8, getAll.Top);
            choose.Location = new Point(rightHead.Right - choose.Width, getAll.Top);
            int dh = (int)(76 * sc);
            drop.SetBounds(rightHead.Left, listTop, colW, dh);
            jobList.SetBounds(rightHead.Left, listTop + dh + (int)(10 * sc), colW, Math.Max(40, listH - dh - (int)(10 * sc)));
            unlink.Location = new Point(stage.Width - unlink.Width - (int)(22 * sc), (int)(20 * sc));
            qrBtn.Location = new Point((int)(28 * sc + 190 * sc + 34 * sc), stage.Height - qrBtn.Height - (int)(24 * sc));
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            K.Smooth(g);
            using (var b = new SolidBrush(K.Text))
            {
                g.DrawString("On your phone", K.F(14f, true), b, leftHead.X + 2, leftHead.Y + 2);
                g.DrawString("Send to your phone", K.F(14f, true), b, rightHead.X + 2, rightHead.Y + 2);
            }
            using (var b = new SolidBrush(K.Mute))
            {
                string c = link == null ? "not linked yet" : (items.Count == 0 ? "nothing shared" : items.Count + (items.Count == 1 ? " item to get" : " items to get"));
                g.DrawString(c, K.F(9f, false), b, leftHead.X + 3, leftHead.Y + 25);
                g.DrawString("Drop files, or choose them. Folders work too.", K.F(9f, false), b, rightHead.X + 3, rightHead.Y + 25);
            }
        }

        // ───────────── animation and numbers ─────────────

        void Frame()
        {
#if MONO_CHECK
            if (demo.Length > 0) { stage.Tick(0.033f); bar.Tick(0.033f); return; }
#endif
            stage.Tick(0.033f);
            bar.Tick(0.033f);
            ticks++;
            if (ticks % 6 == 0) RefreshJobs();
            if (ticks % 15 == 0) Speeds();
        }

        void Speeds()
        {
            DateTime now = DateTime.UtcNow;
            double dt = Math.Max(0.1, (now - lastSpeed).TotalSeconds);
            long up = Interlocked.Read(ref eng.BytesUp), down = Interlocked.Read(ref eng.BytesDown);
            double u = (up - lastUp) / dt / 1e6, d = (down - lastDown) / dt / 1e6;
            lastUp = up; lastDown = down; lastSpeed = now;
            stage.ToPhoneMB = u > 0.05 ? stage.ToPhoneMB * 0.4 + u * 0.6 : 0;
            stage.ToPcMB = d > 0.05 ? stage.ToPcMB * 0.4 + d * 0.6 : 0;
            aggSpeed = (float)(stage.ToPhoneMB + stage.ToPcMB);
        }

        void RefreshJobs()
        {
            Job[] js;
            lock (eng.Jobs) js = eng.Jobs.ToArray();
            bool toPhone = false, toPc = false, active = false;
            var rows = new List<RowData>();
            foreach (Job j in js)
            {
                var r = new RowData();
                r.Title = j.Name;
                r.Chip = Chip(j.Name);
                r.Color = j.Up ? K.Green : K.Blue;
                r.Tag = j;
                long done = Interlocked.Read(ref j.Done);
                if (j.State == "Moving" || j.State == "Waiting")
                {
                    active = true;
                    if (j.State == "Moving") { if (j.Up) toPhone = true; else toPc = true; }
                    r.Sub = (j.State == "Waiting" ? "Waiting" : "Moving") + "  " + (j.Up ? "to the phone" : "from the phone") + "  " + K.Size(j.Total);
                    r.SubColor = j.State == "Waiting" ? K.Mute : r.Color;
                }
                else if (j.State == "Done")
                {
                    double secs = Math.Max(0.05, (j.Ended - j.Started).TotalSeconds);
                    r.Sub = "Done  " + (j.Up ? "sent  " : "saved  ") + K.Size(j.Total) + "  at " + (j.Total / secs / 1e6).ToString("0.0") + " MB/s";
                    r.SubColor = r.Color;
                    if (!j.Up) r.Button = "Show";
                }
                else
                {
                    r.Sub = "Failed: " + j.Note;
                    r.SubColor = K.Bad;
                }
                rows.Add(r);
            }
            stage.ToPhone = toPhone;
            stage.ToPc = toPc;
            jobList.SetItems(rows);

            // one overall picture: every file in this batch, both directions
            if (active && batchDone) { batch.Clear(); batchDone = false; }
            foreach (Job j in js) if (j.State == "Moving" || j.State == "Waiting") batch.Add(j);
            long tot = 0, got = 0;
            foreach (Job j in batch)
            {
                tot += j.Total;
                got += j.State == "Done" ? j.Total : Math.Min(j.Total, Interlocked.Read(ref j.Done));
            }
            if (!active && batch.Count > 0 && !batchDone)
            {
                batchDone = true;
                bar.Burst();
                stage.Splash();
            }
            float frac = tot > 0 ? Math.Min(1f, (float)((double)got / tot)) : 0f;
            if (batchDone && tot > 0) frac = 1f;
            bar.Frac = frac;
            bar.Mbs = aggSpeed;
            bar.Finished = batchDone && tot > 0;
            bar.Eta = !batchDone && aggSpeed > 0.05f ? (int)((tot - got) / 1e6 / aggSpeed) : -1;
            bar.Idle = link == null ? "Link your phone first" : "Nothing moving yet";
            stage.Frac = frac;
            stage.Moving = active;
            stage.AllDone = batchDone && tot > 0;
        }

        static string Chip(string name)
        {
            string e = Path.GetExtension(name);
            if (e.Length > 1) e = e.Substring(1).ToUpperInvariant();
            else e = "FILE";
            return e.Length > 4 ? e.Substring(0, 4) : e;
        }

        void RefreshPhone()
        {
            var rows = new List<RowData>();
            foreach (Item it in items)
            {
                var r = new RowData();
                r.Title = it.Name;
                r.Sub = K.Size(it.Size) + (it.Kind == "app" ? "  app" : "");
                r.Chip = it.Kind == "app" ? "APK" : Chip(it.Name);
                r.Color = K.Blue;
                r.Button = "Get";
                r.Tag = it;
                rows.Add(r);
            }
            phoneList.SetItems(rows);
            Invalidate(leftHead);
        }

        // ───────────── finding and linking ─────────────

        async void Loop()
        {
#if MONO_CHECK
            if (demo.Length > 0) { Demo(); return; }
#endif
            int misses = 0;
            while (!closing)
            {
                try
                {
                    if (link == null)
                    {
                        if (stage.State != Stage.S.Denied && stage.State != Stage.S.Qr && DateTime.UtcNow > hintHold) { stage.State = Stage.S.Searching; stage.Hint = "Open WaveLink on the phone. Same Wi-Fi, hotspot or USB link, or tap Connect by QR."; }
                        List<PhoneInfo> found = await Disco.Find(cts.Token);
                        if (found.Count == 0) { await Task.Delay(1200); continue; }
                        PhoneInfo p = found[0];
                        foreach (PhoneInfo f in found) if (Cfg.Find(f.Id) != null) { p = f; break; }
                        string[] known = Cfg.Find(p.Id);
                        var l = new Link();
                        l.Phone = p;
                        bool ok = false;
                        if (known != null)
                        {
                            l.Token = known[2];
                            List<Item> first = await l.Items();
                            if (first != null) { ok = true; items = first; }
                            else if (!l.Unauthorized) { await Task.Delay(1200); continue; }
                        }
                        if (!ok)
                        {
                            stage.State = Stage.S.Approve;
                            stage.Hint = "Your phone is asking: allow " + Cfg.PcName + "? You only do this once.";
                            string token = await Link.Pair(p);
                            if (token == null)
                            {
                                stage.State = Stage.S.Denied;
                                stage.Hint = "Say Allow on the phone when it asks. Asking again in a moment.";
                                await Task.Delay(12000);
                                continue;
                            }
                            l.Token = token;
                            List<Item> first = await l.Items();
                            if (first != null) items = first;
                        }
                        Cfg.Remember(p.Id, p.Name, l.Token, p.Ip, p.Port);
                        link = l;
                        misses = 0;
                        stage.PhoneName = p.Name;
                        stage.State = Stage.S.Linked;
                        stage.Hint = "";
                        stage.Qr = null;
                        qrBtn.Visible = false;
                        qrBtn.Text = "Connect by QR";
                        unlink.Visible = true;
                        stage.Splash();
                        RefreshPhone();
                    }
                    else
                    {
                        List<Item> it = await link.Items();
                        if (it == null)
                        {
                            if (link.Unauthorized) { Cfg.Forget(link.Phone.Id); LoseLink(); }
                            else if (++misses >= 3) LoseLink();
                        }
                        else
                        {
                            misses = 0;
                            if (Changed(it)) { items = it; RefreshPhone(); }
                        }
                        await Task.Delay(1500);
                    }
                }
                catch (Exception) { await Task.Delay(1500); }
            }
        }

        bool Changed(List<Item> n)
        {
            if (n.Count != items.Count) return true;
            for (int i = 0; i < n.Count; i++) if (n[i].Id != items[i].Id || n[i].Size != items[i].Size || n[i].Name != items[i].Name) return true;
            return false;
        }

        void LoseLink()
        {
            link = null;
            items = new List<Item>();
            stage.State = Stage.S.Searching;
            unlink.Visible = false;
            qrBtn.Visible = true;
            searchSince = DateTime.UtcNow;
            RefreshPhone();
        }

        void Unlink()
        {
            if (link != null) Cfg.Forget(link.Phone.Id);
            LoseLink();
        }

        // ───────────── actions ─────────────

        void OnPhoneClick(RowData r)
        {
            var it = r.Tag as Item;
            if (it != null && link != null) eng.Download(link, it);
        }

        void OnJobClick(RowData r)
        {
            var j = r.Tag as Job;
            if (j == null || j.Up || j.Path.Length == 0) return;
            try { Process.Start("explorer.exe", "/select,\"" + j.Path + "\""); } catch (Exception) { }
        }

        void GetAll()
        {
            if (link == null) return;
            foreach (Item it in items.ToArray()) eng.Download(link, it);
        }

        void OpenDir()
        {
            try
            {
                Directory.CreateDirectory(Cfg.Dir);
                Process.Start("explorer.exe", "\"" + Cfg.Dir + "\"");
            }
            catch (Exception) { }
        }

        void Choose()
        {
            if (link == null) { stage.Hint = "Not linked yet. Open WaveLink on the phone first."; return; }
            using (var d = new OpenFileDialog())
            {
                d.Multiselect = true;
                d.Title = "Send to the phone";
                if (d.ShowDialog(this) == DialogResult.OK) Send(d.FileNames);
            }
        }

        void Send(string[] paths)
        {
            if (link == null) return;
            int n = 0;
            foreach (string p in paths)
            {
                try
                {
                    if (File.Exists(p)) { eng.Upload(link, p); n++; }
                    else if (Directory.Exists(p))
                        foreach (string f in Directory.GetFiles(p, "*", SearchOption.AllDirectories))
                        {
                            if (n >= 500) break;
                            eng.Upload(link, f);
                            n++;
                        }
                }
                catch (Exception) { }
            }
        }

        void OnDragEnter(object s, DragEventArgs e)
        {
            if (link != null && e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
                drop.Hot = true;
                drop.Invalidate();
            }
            else e.Effect = DragDropEffects.None;
        }

        void OnDragDrop(object s, DragEventArgs e)
        {
            drop.Hot = false;
            drop.Invalidate();
            var files = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (files != null) Send(files);
        }

        // ───────────── connect by QR: this PC makes a hotspot, the phone scans and joins it ─────────────

        static string Rand(int n)
        {
            const string chars = "abcdefghjkmnpqrstuvwxyz23456789";
            var b = new byte[n];
            using (var rng = System.Security.Cryptography.RandomNumberGenerator.Create()) rng.GetBytes(b);
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < n; i++) sb.Append(chars[b[i] % chars.Length]);
            return sb.ToString();
        }

#if MONO_CHECK
        readonly string demo = Environment.GetEnvironmentVariable("WL_DEMO") ?? "";
        void Demo()
        {
            qrBtn.Visible = demo == "search" || demo == "qr";
            if (demo == "qr")
            {
                stage.Qr = Qrm.Make("x"); stage.State = Stage.S.Qr; stage.Hint = ""; qrBtn.Text = "Cancel";
            }
            if (demo == "move" || demo == "done" || demo == "linked")
            {
                stage.State = Stage.S.Linked; stage.PhoneName = "Galaxy Note10+"; unlink.Visible = true;
            }
            var rows = new List<RowData>();
            if (demo == "move" || demo == "done")
            {
                string[] n = { "IMG_2041.jpg", "Holiday-4K.mp4", "Report.pdf", "Mixtape.mp3" };
                for (int i = 0; i < n.Length; i++)
                {
                    var r = new RowData(); r.Title = n[i]; r.Chip = Chip(n[i]); r.Color = i % 2 == 0 ? K.Green : K.Blue;
                    bool fin = demo == "done" || i == 0;
                    r.Sub = fin ? "Done  saved  12.4 MB  at 21.3 MB/s" : (i == 1 ? "Moving  from the phone  310 MB" : "Waiting  to the phone  4.1 MB");
                    r.SubColor = fin || i == 1 ? r.Color : K.Mute;
                    rows.Add(r);
                }
                jobList.SetItems(rows);
                bar.Mbs = 18.4f; bar.Eta = 23; stage.ToPhoneMB = 11; stage.ToPcMB = 7.4;
                if (demo == "move") { bar.Frac = 0.62f; stage.Frac = 0.62f; stage.Moving = true; }
                else { bar.Frac = 1f; stage.Frac = 1f; bar.Finished = true; stage.AllDone = true; bar.Burst(); stage.Splash(); }
            }
            if (demo != "search") { var it = new List<RowData>(); var q = new RowData(); q.Title = "Beach.jpg"; q.Sub = "3.2 MB"; q.Chip = "JPG"; q.Button = "Get"; it.Add(q); phoneList.SetItems(it); }
        }
#endif
        bool qrBusy;
        DateTime hintHold = DateTime.MinValue;

        async void ToggleQr()
        {
            if (qrBusy) return;
            if (stage.State == Stage.S.Qr)
            {
                qrBusy = true;
                stage.Qr = null;
                stage.State = Stage.S.Searching;
                qrBtn.Text = "Connect by QR";
                try { await Hot.Stop(); } catch (Exception) { }
                qrBusy = false;
                return;
            }
            if (link != null) return;
            qrBusy = true;
            stage.Hint = "Making a hotspot on this PC...";
            string ssid = "WaveLink-" + Rand(4), pass = Rand(10);
            string err = null;
            try { err = await Hot.Start(ssid, pass); }
            catch (Exception e) { err = e.Message; }
            qrBusy = false;
            if (err != null)
            {
                hintHold = DateTime.UtcNow.AddSeconds(14);
                stage.Hint = err + "\nOr put the phone and the PC on the same Wi-Fi and they find each other with no code.";
                return;
            }
            string code = "wavelink://pc?s=" + Uri.EscapeDataString(ssid) + "&p=" + Uri.EscapeDataString(pass) + "&i=" + Uri.EscapeDataString(Cfg.PcId);
            stage.Qr = Qrm.Make(code);
            stage.State = Stage.S.Qr;
            stage.Hint = "";
            qrBtn.Text = "Cancel";
            stage.Splash();
        }
    }
}
