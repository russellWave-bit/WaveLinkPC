using System;
using System.Collections.Generic;
using System.IO;

namespace WaveLinkPC
{
    /// <summary>What this PC remembers: its own id, the phones it is paired with, and where files go.</summary>
    static class Cfg
    {
        public static string PcId = "";
        public static string PcName = Environment.MachineName;
        public static string Dir = "";
        public static string Ssid = "";
        public static string Pass = "";
        /// <summary>id | name | token | last address | port</summary>
        public static readonly List<string[]> Phones = new List<string[]>();

        static string Folder()
        {
            string home = Environment.GetEnvironmentVariable("WAVELINK_HOME");
            if (!string.IsNullOrEmpty(home)) return home;
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WaveLink");
        }

        static string FilePath() { return Path.Combine(Folder(), "config.txt"); }

        public static string DefaultDir()
        {
            string d = Environment.GetEnvironmentVariable("WAVELINK_DOWNLOADS");
            if (!string.IsNullOrEmpty(d)) return d;
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "WaveLink");
        }

        public static void Load()
        {
            try
            {
                if (File.Exists(FilePath()))
                {
                    foreach (string line in File.ReadAllLines(FilePath()))
                    {
                        int i = line.IndexOf('=');
                        if (i < 1) continue;
                        string k = line.Substring(0, i), v = line.Substring(i + 1);
                        if (k == "pcid") PcId = v;
                        else if (k == "dir") Dir = v;
                        else if (k == "ssid") Ssid = v;
                        else if (k == "wpass") Pass = v;
                        else if (k == "phone")
                        {
                            string[] p = v.Split('|');
                            if (p.Length >= 5) Phones.Add(p);
                        }
                    }
                }
            }
            catch (Exception) { }
            if (PcId.Length == 0) PcId = Guid.NewGuid().ToString("N").Substring(0, 12);
            if (Dir.Length == 0) Dir = DefaultDir();
            Save();
        }

        public static void Save()
        {
            try
            {
                Directory.CreateDirectory(Folder());
                var l = new List<string>();
                l.Add("pcid=" + PcId);
                l.Add("dir=" + Dir);
                l.Add("ssid=" + Ssid);
                l.Add("wpass=" + Pass);
                foreach (string[] p in Phones) l.Add("phone=" + string.Join("|", p));
                File.WriteAllLines(FilePath(), l.ToArray());
            }
            catch (Exception) { }
        }

        public static string[] Find(string id)
        {
            foreach (string[] p in Phones) if (p[0] == id) return p;
            return null;
        }

        public static void Remember(string id, string name, string token, string ip, int port)
        {
            string[] e = Find(id);
            if (e != null) Phones.Remove(e);
            Phones.Insert(0, new string[] { id, name.Replace("|", " "), token, ip, port.ToString() });
            Save();
        }

        public static void Forget(string id)
        {
            string[] e = Find(id);
            if (e != null) { Phones.Remove(e); Save(); }
        }
    }
}
