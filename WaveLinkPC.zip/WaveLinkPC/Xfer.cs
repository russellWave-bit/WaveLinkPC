using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace WaveLinkPC
{
    class Job
    {
        public string Name = "";
        public string Path = "";
        public long Total;
        public long Done;
        /// <summary>true = from this PC to the phone</summary>
        public bool Up;
        public string State = "Waiting";   // Waiting, Moving, Done, Failed
        public string Note = "";
        public DateTime Started, Ended;
    }

    /// <summary>
    /// The fast part. Several files at once, and every big file in pieces at once, each piece on its own
    /// connection, so Wi-Fi stays full. Files are not squeezed (photos and videos are already compressed).
    /// </summary>
    class Engine
    {
        public const long Piece = 8L * 1024 * 1024;
        readonly SemaphoreSlim files = new SemaphoreSlim(3);
        readonly SemaphoreSlim pieces = new SemaphoreSlim(10);
        public readonly List<Job> Jobs = new List<Job>();
        public long BytesUp, BytesDown;
        public event Action<Job> Finished;
        public event Action Changed;

        void Fire() { var h = Changed; if (h != null) h(); }

        Job Add(Job j)
        {
            lock (Jobs) { Jobs.Insert(0, j); if (Jobs.Count > 80) Jobs.RemoveAt(Jobs.Count - 1); }
            Fire();
            return j;
        }

        public static string Unique(string dir, string name)
        {
            Directory.CreateDirectory(dir);
            string clean = name;
            foreach (char c in System.IO.Path.GetInvalidFileNameChars()) clean = clean.Replace(c, '_');
            string p = System.IO.Path.Combine(dir, clean);
            if (!File.Exists(p)) return p;
            string stem = System.IO.Path.GetFileNameWithoutExtension(clean), ext = System.IO.Path.GetExtension(clean);
            for (int i = 1; i < 999; i++)
            {
                p = System.IO.Path.Combine(dir, stem + " (" + i + ")" + ext);
                if (!File.Exists(p)) return p;
            }
            return p;
        }

        // ───────────── phone to PC ─────────────

        public void Download(Link l, Item it)
        {
            var j = Add(new Job { Name = it.Name, Total = it.Size, Up = false });
            Task.Run(() => DoDownload(l, it, j));
        }

        async Task DoDownload(Link l, Item it, Job j)
        {
            await files.WaitAsync();
            string path = null;
            try
            {
                j.State = "Moving";
                j.Started = DateTime.UtcNow;
                Fire();
                path = Unique(Cfg.Dir, it.Name);
                j.Path = path;
                long size = it.Size;
                using (var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.ReadWrite)) { if (size > 0) fs.SetLength(size); }
                if (size > 0)
                {
                    int n = size > 3 * Piece ? 4 : 1;
                    long per = (size + n - 1) / n;
                    var tasks = new List<Task>();
                    for (int i = 0; i < n; i++)
                    {
                        long from = i * per, to = Math.Min(size - 1, from + per - 1);
                        if (from > to) break;
                        tasks.Add(Pull(l, it.Id, path, from, to, j));
                    }
                    await Task.WhenAll(tasks);
                }
                j.State = "Done";
            }
            catch (Exception e)
            {
                j.State = "Failed";
                j.Note = e.Message;
                try { if (path != null) File.Delete(path); } catch (Exception) { }
            }
            finally
            {
                j.Ended = DateTime.UtcNow;
                files.Release();
                Fire();
                var h = Finished;
                if (h != null) h(j);
            }
        }

        async Task Pull(Link l, int id, string path, long from, long to, Job j)
        {
            Exception last = null;
            for (int attempt = 0; attempt < 3; attempt++)
            {
                long counted = 0;
                try
                {
                    await pieces.WaitAsync();
                    try
                    {
                        var r = l.Req(HttpMethod.Get, "/f/" + id);
                        r.Headers.Range = new RangeHeaderValue(from, to);
                        using (HttpResponseMessage resp = await Link.Http.SendAsync(r, HttpCompletionOption.ResponseHeadersRead))
                        {
                            if (!resp.IsSuccessStatusCode) throw new IOException("The phone refused (" + (int)resp.StatusCode + ")");
                            using (Stream s = await resp.Content.ReadAsStreamAsync())
                            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Write, FileShare.ReadWrite, 1 << 16))
                            {
                                fs.Seek(from, SeekOrigin.Begin);
                                byte[] buf = new byte[1 << 20];
                                long pos = from;
                                while (pos <= to)
                                {
                                    int want = (int)Math.Min(buf.Length, to - pos + 1);
                                    int n = await s.ReadAsync(buf, 0, want);
                                    if (n <= 0) throw new IOException("The link was cut");
                                    await fs.WriteAsync(buf, 0, n);
                                    pos += n;
                                    counted += n;
                                    Interlocked.Add(ref j.Done, n);
                                    Interlocked.Add(ref BytesDown, n);
                                }
                            }
                        }
                        return;
                    }
                    finally { pieces.Release(); }
                }
                catch (Exception e)
                {
                    last = e;
                    Interlocked.Add(ref j.Done, -counted);
                    await Task.Delay(400);
                }
            }
            throw last ?? new IOException("failed");
        }

        // ───────────── PC to phone ─────────────

        public void Upload(Link l, string file)
        {
            long size = 0;
            try { size = new FileInfo(file).Length; } catch (Exception) { }
            var j = Add(new Job { Name = System.IO.Path.GetFileName(file), Path = file, Total = size, Up = true });
            Task.Run(() => DoUpload(l, file, size, j));
        }

        async Task DoUpload(Link l, string file, long size, Job j)
        {
            await files.WaitAsync();
            try
            {
                j.State = "Moving";
                j.Started = DateTime.UtcNow;
                Fire();
                string sid = Guid.NewGuid().ToString("N");
                int n = (int)Math.Max(1, (size + Piece - 1) / Piece);
                var tasks = new List<Task>();
                for (int i = 0; i < n; i++)
                {
                    long off = i * Piece, len = Math.Min(Piece, size - off);
                    if (size == 0) len = 0;
                    tasks.Add(Push(l, file, sid, size, off, len, j));
                }
                await Task.WhenAll(tasks);
                j.State = "Done";
            }
            catch (Exception e)
            {
                j.State = "Failed";
                j.Note = e.Message;
            }
            finally
            {
                j.Ended = DateTime.UtcNow;
                files.Release();
                Fire();
                var h = Finished;
                if (h != null) h(j);
            }
        }

        async Task Push(Link l, string file, string sid, long size, long off, long len, Job j)
        {
            Exception last = null;
            for (int attempt = 0; attempt < 3; attempt++)
            {
                long before = 0;
                try
                {
                    await pieces.WaitAsync();
                    try
                    {
                        string q = "/put?name=" + Uri.EscapeDataString(j.Name) + "&size=" + size + "&off=" + off + "&sid=" + sid;
                        var r = l.Req(HttpMethod.Put, q);
                        var content = new PieceContent(file, off, len, delegate (int n)
                        {
                            before += n;
                            Interlocked.Add(ref j.Done, n);
                            Interlocked.Add(ref BytesUp, n);
                        });
                        r.Content = content;
                        using (HttpResponseMessage resp = await Link.Http.SendAsync(r))
                        {
                            if (!resp.IsSuccessStatusCode) throw new IOException("The phone refused (" + (int)resp.StatusCode + ")");
                        }
                        return;
                    }
                    finally { pieces.Release(); }
                }
                catch (Exception e)
                {
                    last = e;
                    Interlocked.Add(ref j.Done, -before);
                    await Task.Delay(400);
                }
            }
            throw last ?? new IOException("failed");
        }
    }

    /// <summary>One slice of a file, streamed to the phone without loading it all into memory.</summary>
    class PieceContent : HttpContent
    {
        readonly string file;
        readonly long off, len;
        readonly Action<int> count;

        public PieceContent(string file, long off, long len, Action<int> count)
        {
            this.file = file;
            this.off = off;
            this.len = len;
            this.count = count;
            Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            Headers.ContentLength = len;
        }

        protected override async Task SerializeToStreamAsync(Stream stream, TransportContext context)
        {
            if (len == 0) return;
            using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, 1 << 16, true))
            {
                fs.Seek(off, SeekOrigin.Begin);
                byte[] buf = new byte[256 * 1024];
                long left = len;
                while (left > 0)
                {
                    int n = await fs.ReadAsync(buf, 0, (int)Math.Min(buf.Length, left));
                    if (n <= 0) throw new IOException("The file changed while sending");
                    await stream.WriteAsync(buf, 0, n);
                    left -= n;
                    count(n);
                }
            }
        }

        protected override bool TryComputeLength(out long length)
        {
            length = len;
            return true;
        }
    }
}
