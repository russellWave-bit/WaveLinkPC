using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;
#if !MONO_CHECK
using Windows.Networking.Connectivity;
using Windows.Networking.NetworkOperators;
using QRCoder;
#endif

namespace WaveLinkPC
{
    /// <summary>Shared water drawing: surfaces and the splash (drawn again natively from the Sakuga recipe).</summary>
    static class Fx
    {
        /// <summary>A filled shape whose top edge is a sine wave, from x0 to x1, down to bottom.</summary>
        public static PointF[] Surface(float x0, float x1, float top, float bottom, float amp, float k, float phase)
        {
            var l = new List<PointF>();
            float w = Math.Max(1f, x1 - x0);
            for (float x = 0; x <= w + 3f; x += 3f)
                l.Add(new PointF(x0 + Math.Min(x, w), top + (float)Math.Sin(x / w * 2 * Math.PI * k + phase) * amp));
            l.Add(new PointF(x1, bottom));
            l.Add(new PointF(x0, bottom));
            return l.ToArray();
        }

        static float R(Random r) { return (float)r.NextDouble(); }

        /// <summary>
        /// Seven water tongues rising and falling over 0.7 s, and seven drops thrown out and pulled down.
        /// t is seconds since the splash began; u scales it for the screen.
        /// </summary>
        public static void Splash(Graphics g, float t, int seed, float ox, float oy, float u)
        {
            if (t < 0f || t >= 1.4f) return;
            for (int k = 0; k < 7; k++)
            {
                var r = new Random(seed * 131 + k * 17 + 3);
                float lean = (k - 3) * 0.24f + (R(r) - 0.5f) * 0.3f;
                float stagger = R(r) * 0.14f;
                float rh = 46f + R(r) * 26f;
                float l = (t - stagger) / 0.7f;
                if (l <= 0f || l >= 1f) continue;
                float big = 1f - Math.Abs(k - 3) * 0.13f;
                float h = (float)Math.Sin(l * Math.PI) * rh * big * u;
                float wd = (12f - l * 4f) * u;
                float bx = ox + (k - 3) * 9f * u;
                float tx = bx + (float)Math.Sin(lean) * h, ty = oy - (float)Math.Cos(lean) * h;
                using (var p = new GraphicsPath())
                {
                    p.AddBezier(bx - wd / 2, oy, bx - wd / 2 + (tx - bx) * 0.3f, oy - h * 0.3f, bx - wd / 2 + (tx - bx) * 0.6f, oy - h * 0.8f, tx, ty);
                    p.AddBezier(tx, ty, bx + wd / 2 + (tx - bx) * 0.6f, oy - h * 0.8f, bx + wd / 2 + (tx - bx) * 0.3f, oy - h * 0.3f, bx + wd / 2, oy);
                    p.CloseFigure();
                    using (var b = new SolidBrush(K.Aqua)) g.FillPath(b, p);
                    using (var pen = new Pen(K.Ink, Math.Max(1f, 1.5f * u))) g.DrawPath(pen, p);
                }
                using (var b = new SolidBrush(Color.White)) g.FillEllipse(b, tx - 2.2f * u, ty - 2.2f * u, 4.4f * u, 4.4f * u);
            }
            for (int k = 0; k < 7; k++)
            {
                var r = new Random(seed * 977 + k * 29 + 11);
                float ang = (float)(-Math.PI / 2) + (R(r) - 0.5f) * 2.2f;
                float sp = (90f + R(r) * 90f) * u;
                float rad = (2f + R(r) * 2f) * u;
                if (t >= 1f) continue;
                float shrink = t > 0.6f ? 1f - (t - 0.6f) / 0.4f : 1f;
                float x = ox + (float)Math.Cos(ang) * sp * t;
                float y = oy + (float)Math.Sin(ang) * sp * t + 330f * u * t * t;
                float rr = Math.Max(0.5f, rad * shrink);
                using (var b = new SolidBrush(K.Aqua)) g.FillEllipse(b, x - rr, y - rr, rr * 2, rr * 2);
                using (var pen = new Pen(K.Ink, Math.Max(1f, 1.1f * u))) g.DrawEllipse(pen, x - rr, y - rr, rr * 2, rr * 2);
                using (var b = new SolidBrush(Color.White)) g.FillEllipse(b, x - rr * 0.5f, y - rr * 0.6f, rr * 0.7f, rr * 0.7f);
            }
        }

        public static string Eta(int s)
        {
            if (s < 0) return "Working out the time left";
            if (s < 2) return "Almost there";
            if (s < 60) return "About " + s + " s left";
            if (s < 3600) return "About " + (s / 60) + " min " + (s % 60) + " s left";
            return "About " + (s / 3600) + " h " + ((s % 3600) / 60) + " min left";
        }
    }

    /// <summary>
    /// The one overall bar. Water pours along it, a crest rides the leading edge, drops fly off backwards,
    /// a dashed ground line runs underneath with bubbles that lift as the water passes, and at 100 % it splashes.
    /// </summary>
    class Overall : Control
    {
        public float Frac, Mbs;
        public int Eta = -1;
        public bool Finished;
        public string Idle = "Nothing moving yet";
        float p, t, splashT = 99f;
        int seed;
        static Font pctFont, jpFont;

        public Overall()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(900, 142);
        }

        public void Burst() { splashT = 0f; seed++; }

        public void Tick(float dt)
        {
            t += dt;
            p += (Frac - p) * Math.Min(1f, dt * 6f);
            if (splashT < 3f) splashT += dt;
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent != null ? Parent.BackColor : K.Bg);
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            float W = Width;
            float bw = 3f * sc, bx = 2 * sc, bwid = W - 4 * sc, by = 34 * sc, bh = 36 * sc, rr = 13 * sc;
            bool active = Frac > 0.0001f || Finished;
            float ex = bx + bwid * Math.Min(1f, p);

            using (var b = new SolidBrush(K.Mute)) g.DrawString("Everything moving", K.F(9.5f, true), b, 2 * sc, 4 * sc);

            using (var path = K.Round(new RectangleF(bx, by, bwid, bh), rr))
            using (var b = new SolidBrush(Color.White)) g.FillPath(b, path);

            if (p > 0.002f)
            {
                var inner = new RectangleF(bx + bw, by + bw, bwid - 2 * bw, bh - 2 * bw);
                using (var clip = K.Round(inner, Math.Max(1f, rr - bw)))
                {
                    g.SetClip(clip);
                    var pts = new List<PointF>();
                    pts.Add(new PointF(bx, by));
                    for (float y = 0; y <= bh; y += 3 * sc)
                        pts.Add(new PointF(ex + (float)Math.Sin(y / sc * 0.3 - t * 6) * 3.5f * sc, by + y));
                    pts.Add(new PointF(bx, by + bh));
                    using (var fp = new GraphicsPath())
                    {
                        fp.AddPolygon(pts.ToArray());
                        using (var br = new LinearGradientBrush(new RectangleF(bx, by, Math.Max(4f, bwid), bh), K.Aqua, K.Deep, 0f)) g.FillPath(br, fp);
                        g.SetClip(fp, CombineMode.Intersect);
                        for (int k = 0; k < 2; k++)
                        {
                            var line = new List<PointF>();
                            float yy = by + bh * (0.38f + 0.26f * k);
                            for (float x = bx; x <= ex + 12 * sc; x += 6f)
                                line.Add(new PointF(x, yy + (float)Math.Sin(x / sc * 0.045 + t * (2.2 + k) + k * 2) * 4 * sc));
                            if (line.Count > 1) using (var pen = new Pen(Color.FromArgb(100, Color.White), 2 * sc)) g.DrawLines(pen, line.ToArray());
                        }
                        for (int k = 0; k < 2; k++)
                        {
                            float span = Math.Max(10f, ex - bx) + 90 * sc;
                            float sx = bx + ((t * 70 * sc + k * bwid * 0.5f) % span) - 40 * sc;
                            var sk = new PointF[] { new PointF(sx, by), new PointF(sx + 16 * sc, by), new PointF(sx + 4 * sc, by + bh), new PointF(sx - 12 * sc, by + bh) };
                            using (var b = new SolidBrush(Color.FromArgb(56, Color.White))) g.FillPolygon(b, sk);
                        }
                    }
                    g.ResetClip();
                }
            }

            // the crest riding the leading edge, and drops shed backwards
            if (p > 0.01f && p < 0.999f)
            {
                for (int k = 0; k < 5; k++)
                {
                    float cy = by + bh * (k + 0.5f) / 5f;
                    float h = (0.45f + (float)Math.Sqrt(p) * 0.9f) * 15 * sc * (0.6f + 0.4f * (float)Math.Sin(t * 5 + k * 1.7));
                    using (var tp = new GraphicsPath())
                    {
                        tp.AddBezier(ex - 2 * sc, cy - 5 * sc, ex + h * 0.2f, cy - 5 * sc, ex + h * 0.7f, cy - 4 * sc, ex + h, cy - h * 0.15f);
                        tp.AddBezier(ex + h, cy - h * 0.15f, ex + h * 0.7f, cy + 4 * sc, ex + h * 0.2f, cy + 5 * sc, ex - 2 * sc, cy + 5 * sc);
                        tp.CloseFigure();
                        using (var b = new SolidBrush(K.Aqua)) g.FillPath(b, tp);
                        using (var pen = new Pen(K.Ink, 1.5f * sc)) g.DrawPath(pen, tp);
                    }
                    using (var b = new SolidBrush(Color.White)) g.FillEllipse(b, ex + h * 0.88f - 2 * sc, cy - h * 0.12f - 2 * sc, 4 * sc, 4 * sc);
                }
                float rate = 0.5f + Math.Min(2f, Mbs / 12f);
                for (int k = 0; k < 8; k++)
                {
                    float ph = (t * rate + k / 8f) % 1f;
                    var r = new Random(k * 7 + 1);
                    float s = ph * 0.8f;
                    float x = ex - (30f + (float)r.NextDouble() * 60f) * sc * s;
                    float y = by + bh * (0.15f + (float)r.NextDouble() * 0.7f) - (50f + (float)r.NextDouble() * 70f) * sc * s + 620f * sc * s * s * 0.5f;
                    int a = (int)(255 * (1f - ph));
                    if (y < by + bh + 18 * sc)
                    {
                        using (var b = new SolidBrush(Color.FromArgb(a, K.Aqua))) g.FillEllipse(b, x - 3 * sc, y - 3 * sc, 6 * sc, 6 * sc);
                        using (var pen = new Pen(Color.FromArgb((int)(a * 0.8f), K.Ink), 1f)) g.DrawEllipse(pen, x - 3 * sc, y - 3 * sc, 6 * sc, 6 * sc);
                    }
                }
            }
            using (var path = K.Round(new RectangleF(bx + bw / 2, by + bw / 2, bwid - bw, bh - bw), rr))
            using (var pen = new Pen(K.Ink, bw)) g.DrawPath(pen, path);

            // the ground: a dashed wavy line, with bubbles that lift as the water passes
            float gy = by + bh + 18 * sc;
            var gp = new List<PointF>();
            for (float x = 0; x <= W; x += 6f) gp.Add(new PointF(x, gy + (float)Math.Sin(x / sc * 0.05 - t * 2) * 2 * sc));
            using (var pen = new Pen(Color.FromArgb(140, K.Ink), 2 * sc))
            {
                pen.DashStyle = DashStyle.Custom;
                pen.DashPattern = new float[] { 4f, 3f };
                pen.DashOffset = -t * 6f;
                g.DrawLines(pen, gp.ToArray());
            }
            for (int k = 0; k < 6; k++)
            {
                float bxx = W * (k + 0.5f) / 6f;
                float near = Math.Abs(ex - bxx);
                float lift = active && near < 34 * sc ? 9 * sc * (1f - near / (34 * sc)) : 0f;
                float cy = gy - 8 * sc - lift;
                using (var b = new SolidBrush(Color.FromArgb(220, Color.White))) g.FillEllipse(b, bxx - 5 * sc, cy - 5 * sc, 10 * sc, 10 * sc);
                using (var pen = new Pen(Color.FromArgb(180, K.Ink), 1.5f * sc)) g.DrawEllipse(pen, bxx - 5 * sc, cy - 5 * sc, 10 * sc, 10 * sc);
            }

            if (Finished && p > 0.99f)
            {
                float cx = bx + bwid - 22 * sc, cy = by + bh / 2;
                using (var b = new SolidBrush(K.Green)) g.FillEllipse(b, cx - 15 * sc, cy - 15 * sc, 30 * sc, 30 * sc);
                using (var pen = new Pen(K.Ink, 2 * sc)) g.DrawEllipse(pen, cx - 15 * sc, cy - 15 * sc, 30 * sc, 30 * sc);
                using (var pen = new Pen(Color.White, 3 * sc) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                    g.DrawLines(pen, new PointF[] { new PointF(cx - 6 * sc, cy), new PointF(cx - 1.5f * sc, cy + 5 * sc), new PointF(cx + 7 * sc, cy - 5 * sc) });
            }
            Fx.Splash(g, splashT, seed, bx + bwid - 36 * sc, by + bh * 0.5f, 0.9f * sc);

            // the leaning percent box, the sound word, and the time left
            float ly = gy + 14 * sc;
            if (pctFont == null) pctFont = new Font("Segoe UI", 15f, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            if (jpFont == null) jpFont = new Font("Yu Gothic UI", 10.5f, FontStyle.Bold, GraphicsUnit.Point);
            string pct = ((int)Math.Round(Math.Min(1f, p) * 100)) + "%";
            var st = g.Save();
            g.TranslateTransform(8 * sc, ly);
            g.MultiplyTransform(new Matrix(1, 0, -0.22f, 1, 0, 0));
            var box = new RectangleF(0, 0, 74 * sc, 30 * sc);
            using (var b = new SolidBrush(K.Aqua)) g.FillRectangle(b, box.X + 3 * sc, box.Y + 3 * sc, box.Width, box.Height);
            using (var b = new SolidBrush(Color.White)) g.FillRectangle(b, box);
            using (var pen = new Pen(K.Ink, 2f)) g.DrawRectangle(pen, box.X, box.Y, box.Width, box.Height);
            var csf = new StringFormat(); csf.Alignment = StringAlignment.Center; csf.LineAlignment = StringAlignment.Center;
            using (var b = new SolidBrush(K.Ink)) g.DrawString(pct, pctFont, b, box, csf);
            g.Restore(st);

            string msg;
            if (Finished) msg = "ザバーン!  All done";
            else if (active) msg = "ザザザ…  " + Mbs.ToString("0.0") + " MB/s";
            else msg = Idle;
            using (var b = new SolidBrush(Finished ? K.Green : K.Ink)) g.DrawString(msg, active || Finished ? jpFont : K.F(10.5f, true), b, 100 * sc, ly + 4 * sc);
            if (active && !Finished)
            {
                var rsf = new StringFormat(); rsf.Alignment = StringAlignment.Far;
                using (var b = new SolidBrush(K.Mute)) g.DrawString(Fx.Eta(Eta), K.F(10f, true), b, new RectangleF(0, ly + 6 * sc, W - 6 * sc, 22 * sc), rsf);
            }
        }
    }

    /// <summary>
    /// The top card: a round water orb that rises with the link and with the transfer, the state in words,
    /// and, while connecting by QR, the code to scan.
    /// </summary>
    class Stage : Control
    {
        public enum S { Searching, Approve, Linked, Denied, Qr }
        public S State = S.Searching;
        public string PhoneName = "";
        public string Hint = "";
        public bool ToPhone, ToPc;           // moving right now
        public double ToPhoneMB, ToPcMB;
        public float Flash;                  // kept for the engine's finished event
        public bool FlashPhone;
        public float Frac;                   // the overall bar, so the orb fills with it
        public bool Moving, AllDone;
        public bool[,] Qr;
        float t, lv, splashT = 99f;
        int seed;

        public Stage()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(900, 236);
        }

        public void Splash() { splashT = 0f; seed++; }

        public void Tick(float dt)
        {
            t += dt;
            float target;
            if (Moving) target = 0.3f + 0.65f * Frac;
            else if (AllDone) target = 0.95f;
            else if (State == S.Linked) target = 0.62f;
            else if (State == S.Qr) target = 0.45f;
            else if (State == S.Approve) target = 0.5f;
            else target = 0.3f;
            lv += (target - lv) * Math.Min(1f, dt * 3f);
            Flash = Math.Max(0f, Flash - dt * 1.4f);
            if (splashT < 3f) splashT += dt;
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent != null ? Parent.BackColor : K.Bg);
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            K.Smooth(g);
            float sc = K.Sc(this);
            var r = new RectangleF(1, 1, Width - 3, Height - 3);
            using (var p = K.Round(r, 22 * sc))
            {
                using (var b = new SolidBrush(Color.White)) g.FillPath(b, p);
                using (var pen = new Pen(K.Line, 1.5f)) g.DrawPath(pen, p);
            }

            // the orb
            float D = Math.Min(Height - 44 * sc, 190 * sc);
            float ox = 28 * sc, oy = (Height - D) / 2f;
            using (var b = new SolidBrush(K.Paper)) g.FillEllipse(b, ox, oy, D, D);
            using (var clip = new GraphicsPath())
            {
                clip.AddEllipse(ox, oy, D, D);
                g.SetClip(clip);
                float top = oy + D * (1f - lv);
                using (var b = new SolidBrush(Color.FromArgb(140, K.Aqua))) g.FillPolygon(b, Fx.Surface(ox, ox + D, top, oy + D + 2, 7 * sc, 1.3f, t * 1.7f));
                using (var b = new SolidBrush(Color.FromArgb(190, K.AquaD))) g.FillPolygon(b, Fx.Surface(ox, ox + D, top + 3 * sc, oy + D + 2, 6 * sc, 1.8f, -t * 2.3f + 1.5f));
                for (int k = 0; k < 5; k++)
                {
                    float ph = (t * 0.18f + k * 0.21f) % 1f;
                    float bxx = ox + D * (0.2f + 0.15f * k) + (float)Math.Sin(t + k) * 6 * sc;
                    float byy = oy + D - ph * D * lv;
                    float rad = (3 + k % 3) * sc;
                    using (var b = new SolidBrush(Color.FromArgb((int)(120 * (1f - ph)), Color.White))) g.FillEllipse(b, bxx - rad, byy - rad, rad * 2, rad * 2);
                }
                g.ResetClip();
            }
            using (var pen = new Pen(K.Ink, 3.5f * sc)) g.DrawEllipse(pen, ox + 1.5f * sc, oy + 1.5f * sc, D - 3 * sc, D - 3 * sc);

            string ot, os;
            Color oc = K.Ink;
            if (Moving) { ot = ((int)Math.Round(Frac * 100)) + "%"; os = (ToPhoneMB + ToPcMB).ToString("0.0") + " MB/s"; }
            else if (AllDone) { ot = "All done"; os = ""; }
            else switch (State)
                {
                    case S.Linked: ot = "Linked"; os = PhoneName; break;
                    case S.Approve: ot = "Allow it"; os = "on your phone"; break;
                    case S.Denied: ot = "Not yet"; os = "trying again"; break;
                    case S.Qr: ot = "Scan me"; os = "with your phone"; break;
                    default: ot = "Looking"; os = "for your phone"; break;
                }
            var csf = new StringFormat(); csf.Alignment = StringAlignment.Center; csf.LineAlignment = StringAlignment.Center;
            using (var b = new SolidBrush(oc))
            {
                g.DrawString(ot, K.F(17f, true), b, new RectangleF(ox, oy + D * 0.30f, D, D * 0.22f), csf);
                if (os.Length > 0) g.DrawString(os, K.F(9.5f, true), b, new RectangleF(ox + 10 * sc, oy + D * 0.52f, D - 20 * sc, D * 0.14f), csf);
            }
            Fx.Splash(g, splashT, seed, ox + D / 2, oy + D * 0.45f, 1.2f * sc);

            // the words
            float tx = ox + D + 34 * sc;
            float right = Width - 28 * sc;
            float qs = 0;
            if (State == S.Qr && Qr != null)
            {
                qs = Math.Min(Height - 52 * sc, 188 * sc);
                float qx = Width - 28 * sc - qs, qy = 16 * sc;
                right = qx - 24 * sc;
                var panel = new RectangleF(qx, qy, qs, qs);
                using (var p = K.Round(panel, 14 * sc))
                {
                    using (var b = new SolidBrush(Color.White)) g.FillPath(b, p);
                    using (var pen = new Pen(K.Ink, 3 * sc)) g.DrawPath(pen, p);
                }
                int n = Qr.GetLength(0);
                float cell = (qs - 28 * sc) / (n + 2);
                float x0 = qx + 14 * sc + cell, y0 = qy + 14 * sc + cell;
                g.SmoothingMode = SmoothingMode.None;
                using (var b = new SolidBrush(Color.Black))
                    for (int y = 0; y < n; y++)
                        for (int x = 0; x < n; x++)
                            if (Qr[y, x]) g.FillRectangle(b, (float)Math.Floor(x0 + x * cell), (float)Math.Floor(y0 + y * cell), (float)Math.Ceiling(cell) + 0.5f, (float)Math.Ceiling(cell) + 0.5f);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                var qsf = new StringFormat(); qsf.Alignment = StringAlignment.Center;
                using (var b = new SolidBrush(K.Mute)) g.DrawString("Scan with WaveLink", K.F(9f, true), b, new RectangleF(qx - 20 * sc, qy + qs + 4 * sc, qs + 40 * sc, 20 * sc), qsf);
            }

            string line; Color lc = K.Mute;
            switch (State)
            {
                case S.Qr: line = "Connect by QR"; lc = K.AquaD; break;
                case S.Approve: line = "Tap Allow on your phone"; lc = K.AquaD; break;
                case S.Denied: line = "The phone said no. Trying again..."; lc = K.Bad; break;
                case S.Linked: line = "Linked to " + PhoneName; lc = K.Green; break;
                default: line = "Looking for your phone..."; break;
            }
            using (var b = new SolidBrush(K.Ink)) g.DrawString("WaveLink", K.F(22f, true), b, tx, 20 * sc);
            using (var b = new SolidBrush(lc)) g.DrawString(line, K.F(12f, true), b, tx, 58 * sc);
            string body = Hint;
            if (State == S.Qr && Hint.Length == 0) body = "1  Open WaveLink on your phone\n2  Tap Connect by QR\n3  Point the camera at this code\nNothing to type. The phone joins by itself.";
            if (State == S.Linked && Hint.Length == 0) body = "Drop files anywhere on this window to send them to the phone, or pick things in the list below to get them.";
            if (body.Length > 0)
                using (var b = new SolidBrush(K.Mute))
                    g.DrawString(body, K.F(10f, false), b, new RectangleF(tx, 84 * sc, Math.Max(40, right - tx), 90 * sc));

            // the two speeds, bottom right of the words
            if (State != S.Qr)
            {
                float cx = Math.Max(tx, right - 330 * sc), cy = Height - 52 * sc;
                Chip(g, cx, cy, "PC to phone", ToPhone ? ToPhoneMB.ToString("0.0") + " MB/s" : "idle", K.Green, ToPhone, sc);
                Chip(g, cx + 170 * sc, cy, "Phone to PC", ToPc ? ToPcMB.ToString("0.0") + " MB/s" : "idle", K.Blue, ToPc, sc);
            }
        }

        void Chip(Graphics g, float x, float y, string label, string value, Color c, bool on, float sc)
        {
            using (var b = new SolidBrush(on ? c : Color.FromArgb(80, c))) g.FillEllipse(b, x, y + 8 * sc, 12 * sc, 12 * sc);
            using (var b = new SolidBrush(K.Mute)) g.DrawString(label, K.F(8.5f, false), b, x + 20 * sc, y - 2 * sc);
            using (var b = new SolidBrush(on ? c : K.Mute)) g.DrawString(value, K.F(12f, true), b, x + 20 * sc, y + 11 * sc);
        }
    }

    /// <summary>Makes this PC's own Wi-Fi hotspot with Windows, so the phone can join it by scanning a QR code.</summary>
    static class Hot
    {
        public static bool On;
#if MONO_CHECK
        public static Task<string> Start(string ssid, string pass) { On = true; return Task.FromResult<string>(null); }
        public static Task Stop() { On = false; return Task.FromResult(0); }
#else
        static NetworkOperatorTetheringManager Mgr()
        {
            ConnectionProfile prof = NetworkInformation.GetInternetConnectionProfile();
            if (prof == null) return null;
            return NetworkOperatorTetheringManager.CreateFromConnectionProfile(prof);
        }

        /// <summary>Returns null when the hotspot is on, or a sentence saying why not.</summary>
        public static async Task<string> Start(string ssid, string pass)
        {
            try
            {
                NetworkOperatorTetheringManager m = Mgr();
                if (m == null) return "Windows can only share a connection this PC already has. Connect the PC to Wi-Fi or a cable first, then try again.";
                if (m.TetheringOperationalState == TetheringOperationalState.On) await m.StopTetheringAsync();
                var cfg = new NetworkOperatorTetheringAccessPointConfiguration();
                cfg.Ssid = ssid;
                cfg.Passphrase = pass;
                await m.ConfigureAccessPointAsync(cfg);
                NetworkOperatorTetheringOperationResult r = await m.StartTetheringAsync();
                if (r.Status != TetheringOperationStatus.Success)
                    return string.IsNullOrEmpty(r.AdditionalErrorMessage) ? "Windows could not start the hotspot (" + r.Status + "). Turn on Mobile hotspot in Windows settings and try again." : r.AdditionalErrorMessage;
                On = true;
                return null;
            }
            catch (Exception e)
            {
                return "Windows could not start the hotspot: " + e.Message;
            }
        }

        public static async Task Stop()
        {
            try
            {
                NetworkOperatorTetheringManager m = Mgr();
                if (m != null && m.TetheringOperationalState == TetheringOperationalState.On) await m.StopTetheringAsync();
            }
            catch (Exception) { }
            On = false;
        }
#endif
    }

    /// <summary>Turns text into the little squares of a QR code.</summary>
    static class Qrm
    {
        public static bool[,] Make(string text)
        {
#if MONO_CHECK
            var lines = System.IO.File.Exists("/tmp/wlt/qr.txt") ? System.IO.File.ReadAllLines("/tmp/wlt/qr.txt") : new string[] { "101", "010", "101" };
            int n = lines.Length;
            var m = new bool[n, n];
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++) m[y, x] = lines[y][x] == '1';
            return m;
#else
            using (var gen = new QRCodeGenerator())
            using (QRCodeData d = gen.CreateQrCode(text, QRCodeGenerator.ECCLevel.M))
            {
                var mm = d.ModuleMatrix;
                int n = mm.Count;
                var m = new bool[n, n];
                for (int y = 0; y < n; y++)
                    for (int x = 0; x < n; x++)
                        m[y, x] = mm[y][x];
                return m;
            }
#endif
        }
    }
}
