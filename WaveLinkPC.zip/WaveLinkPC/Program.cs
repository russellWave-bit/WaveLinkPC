using System;
using System.Threading;
using System.Windows.Forms;

namespace WaveLinkPC
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            bool first;
            using (var m = new Mutex(true, "WaveLinkPC.single", out first))
            {
                if (!first)
                {
                    MessageBox.Show("WaveLink PC is already open.", "WaveLink PC");
                    return;
                }
#if !MONO_CHECK
                Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
#endif
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.ThreadException += (s, e) => { };
                Application.Run(new MainForm());
            }
        }
    }
}
