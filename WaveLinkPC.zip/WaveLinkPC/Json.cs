using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace WaveLinkPC
{
    /// <summary>A tiny JSON reader, enough for the phone's answers. Objects become Dictionary, arrays List.</summary>
    static class Json
    {
        public static object Parse(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            try
            {
                int i = 0;
                return Val(s, ref i);
            }
            catch (Exception)
            {
                return null;
            }
        }

        static void Ws(string s, ref int i)
        {
            while (i < s.Length && char.IsWhiteSpace(s[i])) i++;
        }

        static object Val(string s, ref int i)
        {
            Ws(s, ref i);
            char c = s[i];
            if (c == '{')
            {
                var d = new Dictionary<string, object>();
                i++;
                Ws(s, ref i);
                if (s[i] == '}') { i++; return d; }
                while (true)
                {
                    Ws(s, ref i);
                    string k = Str(s, ref i);
                    Ws(s, ref i);
                    i++; // :
                    d[k] = Val(s, ref i);
                    Ws(s, ref i);
                    if (s[i] == ',') { i++; continue; }
                    i++; // }
                    return d;
                }
            }
            if (c == '[')
            {
                var l = new List<object>();
                i++;
                Ws(s, ref i);
                if (s[i] == ']') { i++; return l; }
                while (true)
                {
                    l.Add(Val(s, ref i));
                    Ws(s, ref i);
                    if (s[i] == ',') { i++; continue; }
                    i++; // ]
                    return l;
                }
            }
            if (c == '"') return Str(s, ref i);
            if (s.Substring(i, Math.Min(4, s.Length - i)) == "true") { i += 4; return true; }
            if (s.Substring(i, Math.Min(5, s.Length - i)) == "false") { i += 5; return false; }
            if (s.Substring(i, Math.Min(4, s.Length - i)) == "null") { i += 4; return null; }
            int st = i;
            while (i < s.Length && "+-0123456789.eE".IndexOf(s[i]) >= 0) i++;
            return double.Parse(s.Substring(st, i - st), CultureInfo.InvariantCulture);
        }

        static string Str(string s, ref int i)
        {
            var sb = new StringBuilder();
            i++; // opening quote
            while (s[i] != '"')
            {
                char c = s[i++];
                if (c == '\\')
                {
                    char n = s[i++];
                    switch (n)
                    {
                        case 'n': sb.Append('\n'); break;
                        case 'r': sb.Append('\r'); break;
                        case 't': sb.Append('\t'); break;
                        case 'b': sb.Append('\b'); break;
                        case 'f': sb.Append('\f'); break;
                        case 'u':
                            sb.Append((char)Convert.ToInt32(s.Substring(i, 4), 16));
                            i += 4;
                            break;
                        default: sb.Append(n); break;
                    }
                }
                else sb.Append(c);
            }
            i++; // closing quote
            return sb.ToString();
        }

        public static object Get(object o, string k)
        {
            var d = o as Dictionary<string, object>;
            object v;
            if (d != null && d.TryGetValue(k, out v)) return v;
            return null;
        }

        public static string S(object o, string k, string def)
        {
            object v = Get(o, k);
            return v == null ? def : Convert.ToString(v, CultureInfo.InvariantCulture);
        }

        public static double N(object o, string k, double def)
        {
            object v = Get(o, k);
            if (v is double) return (double)v;
            return def;
        }

        public static bool B(object o, string k, bool def)
        {
            object v = Get(o, k);
            if (v is bool) return (bool)v;
            return def;
        }
    }

    static class Log
    {
        static readonly List<string> lines = new List<string>();
        public static void Add(string s)
        {
            lock (lines)
            {
                lines.Insert(0, DateTime.Now.ToString("HH:mm:ss") + "  " + s);
                if (lines.Count > 60) lines.RemoveAt(lines.Count - 1);
            }
        }
        public static string[] All()
        {
            lock (lines) return lines.ToArray();
        }
    }
}
